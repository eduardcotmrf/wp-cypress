<?php

namespace Base;

use Ioc\Marfeel_Press_App;
use Base\Marfeel_Press_Activator;

class Marfeel_Press_Updater {

	public function update( $upgrader_object, $options ) {
		if ( $options['action'] == 'update' && $options['type'] == 'plugin' ) {
			foreach ( $options['plugins'] as $each_plugin ) {
				if ( $each_plugin == MRFP_MARFEEL_PRESS_PLUGIN_NAME ) {
					$this->set_resources_host();
					$this->set_activated_once();
					$this->configure_ads_txt();
				}
			}
		}
	}

	private function set_resources_host() {
		$producers_host = Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.producer_host' );

		if ( empty( $producers_host ) ) {
			$activator = new Marfeel_Press_Activator();
			$activator->check_repository_environment();
		}
	}

	private function set_activated_once() {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$activated_once = $settings_service->get( 'marfeel_press.activated_once' );

		if ( empty( $activated_once ) ) {
			$activated = $settings_service->get_availability() === 'ALL';
			$settings_service->set( 'marfeel_press.activated_once', $activated );
		}
	}

	private function configure_ads_txt() {
		Marfeel_Press_App::make( 'ads_txt_plugin_support' )
			->save_mrf_lines( is_plugin_active( 'ads-txt/ads-txt.php' ) );
	}
}
