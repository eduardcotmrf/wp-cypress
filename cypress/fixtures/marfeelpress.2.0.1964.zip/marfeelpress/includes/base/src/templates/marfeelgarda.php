<script data-mrf-script="garda" data-mrf-dt="1" data-mrf-host="<?php echo $host; ?>" src="https://<?php echo $host; ?>/statics/marfeel/gardac-sync.js"></script>
