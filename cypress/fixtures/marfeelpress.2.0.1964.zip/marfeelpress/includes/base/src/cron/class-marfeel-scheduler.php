<?php

namespace Base\Cron;

use Ioc\Marfeel_Press_App;

class Marfeel_Scheduler {

	public function activate() {
		$this->add_cron_time_intervals();
		$this->add_cron_jobs();
	}

	public function deactivate() {
		Marfeel_Press_App::make( 'activation_cron_job' )->deactivate();
	}

	public function add_cron_time_intervals() {
		add_filter( 'cron_schedules', array( $this, 'cron_time_intervals' ) );
	}

	public function cron_time_intervals( $schedules ) {
		$schedules['thirty_seconds'] = array(
			'interval' => 30,
			'display' => 'Every 30 Seconds',
		);

		return $schedules;
	}

	public function add_cron_jobs() {
		Marfeel_Press_App::make( 'activation_cron_job' )->activate();
	}

}
