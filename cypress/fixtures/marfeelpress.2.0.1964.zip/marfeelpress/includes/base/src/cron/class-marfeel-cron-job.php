<?php

namespace Base\Cron;

abstract class Marfeel_Cron_Job {

	/** @var string */
	protected $hook_name;

	/** @var string */
	protected $recurrence = 'daily';

	public function activate() {
		$this->set_action();
		$this->schedule_job();
	}

	public function deactivate() {
		wp_clear_scheduled_hook( $this->hook_name );
	}

	private function set_action() {
		add_action( $this->hook_name, array( $this, 'do_work' ) );
	}

	protected function schedule_job() {
		if ( ! wp_next_scheduled( $this->hook_name ) ) {
			wp_schedule_event( time(), $this->recurrence, $this->hook_name );
		}
	}

	abstract protected function do_work();
}
