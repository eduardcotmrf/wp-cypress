<?php

namespace Base\Cron;

use Ioc\Marfeel_Press_App;

class Marfeel_Activation_Cron_Job extends Marfeel_Cron_Job {

	/** @var string */
	protected $hook_name = 'marfeel_activation';

	/** @var string */
	protected $recurrence = 'thirty_seconds';

	public function schedule_job() {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$pending_to_activate = $settings_service->get( 'marfeel_press.pending_to_activate' );

		if ( ! wp_next_scheduled( $this->hook_name ) && $pending_to_activate ) {
			wp_schedule_event( time(), $this->recurrence, $this->hook_name );
		}
	}

	public function do_work() {
		if ( Marfeel_Press_App::make( 'activation_checker' )->is_prod_ready() ) {
			Marfeel_Press_App::make( 'page_utils' )->activate_all();
			$settings_service = Marfeel_Press_App::make( 'settings_service' );
			$settings_service->set( 'marfeel_press.pending_to_activate', false );
			$this->deactivate();
		}
	}
}
