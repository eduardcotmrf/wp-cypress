<?php

namespace Base;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Router {

	public function __construct() {
		if ( Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.mrf_router_active' ) ) {
			Marfeel_Press_App::make( 'mrf_router' );
		}

		Marfeel_Press_App::make( 'ads_txt_router' );
		Marfeel_Press_App::make( 'sw_router' );

		if ( Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.amp.activate' ) ) {
			Marfeel_Press_App::make( 'amp_router' );
		}

		Marfeel_Press_App::make( 'log_provider' )->debug_if_dev( 'marfeelPressWatcher: Marfeel_Press_Router created' );
	}
}
