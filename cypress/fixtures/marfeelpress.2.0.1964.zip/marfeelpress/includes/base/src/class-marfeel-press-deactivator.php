<?php

namespace Base;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Deactivator {
	const OPTION_PLUGIN_STATUS = 'marfeel_press.plugin_status';

	public function deactivate() {
		flush_rewrite_rules();

		global $wp_rewrite;
		$wp_rewrite->flush_rules();
		$this->track_deactivation();

		if ( is_plugin_active( 'ads-txt/ads-txt.php' ) ) {
			Marfeel_Press_App::make( 'ads_txt_plugin_support' )->remove_mrf_lines();
		}
	}

	public function track_deactivation( $set_plugin_deactivated = true ) {
		$tracker          = Marfeel_Press_App::make( 'tracker' );
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		if ( $set_plugin_deactivated ) {
			$settings_service->set( self::OPTION_PLUGIN_STATUS, 'DEACTIVATED' );
		}

		$tracker->identify( true );
		$tracker->track( 'marfeel/deactivated' );
	}

	public function add_deactivation_popup() {
		global $pagenow;
		if ( $pagenow === 'plugins.php' ) {
			add_action( 'admin_footer', array( $this, 'deactivation_popup' ) );
			$this->load_deactivation_popup_styles();
		}
	}

	public function deactivation_popup() {
		include MRFP__MARFEEL_PRESS_ADMIN_TEMPLATES_DIR . '../../templates/mrf-deactivation-popup-template.php';
	}

	public function enqueue_deactivation_popup_styles() {
		wp_register_style(
			'deactivation_popup',
			MRFP__MARFEEL_PRESS_ADMIN_RESOURCES_DIR . 'dist/main-deactivation-popup.css?buildnumber=' . MRFP_PLUGIN_VERSION
		);
		wp_enqueue_style( 'deactivation_popup' );
	}

	public function load_deactivation_popup_styles() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_deactivation_popup_styles' ) );
	}
}
