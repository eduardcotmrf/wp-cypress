<?php

namespace Base;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Proxy {

	/** @var bool */
	protected $is_amp = false;

	public function execute() {
		$resources_host = Marfeel_Press_App::make( 'definition_service' )->get( 'user_interface.resources_host' );
		$proxy_url = $this->get_proxy_uri();
		$data = false;
		$cache_active = Marfeel_Press_App::make( 'definition_service' )->get( 'marfeel_press.cache_active' );

		if ( $cache_active ) {
			$cache_key = 'marfeel_content_' . $proxy_url;
			$data = get_transient( $cache_key );
		}

		if ( false === $data ) {
			$data = Marfeel_Press_App::make( 'http_client' )->request('GET', $resources_host . $proxy_url, array(
				'timeout' => 20,
				'followlocation' => true,
			));

			if ( $cache_active ) {
				set_transient( $cache_key, $data, HOUR_IN_SECONDS );
			}
		}

		if ( ! is_wp_error( $data ) ) {
			$status_code = $data['response']['code'];

			if ( $status_code == 200 || $this->is_amp ) {
				status_header( $status_code );

				$html = $this->replace_meta_generator( $data['body'] );

				echo $html;

				if ( $this->is_amp && $status_code != 200 ) {
					Marfeel_Press_App::make( 'log_provider' )->write_log( 'proxyAmpError requesting url: ' . $resources_host . $proxy_url . ' with status code: ' . $status_code );
				}

				$this->end_connection();
			} else {
				Marfeel_Press_App::make( 'log_provider' )->write_log( 'Proxy error requesting url: ' . $resources_host . $proxy_url . ' with status code: ' . $status_code );
			}
		} else {
			Marfeel_Press_App::make( 'log_provider' )->write_log( 'Proxy error requesting url: ' . $resources_host . $proxy_url );

			if ( $this->is_amp ) {
				Marfeel_Press_App::make( 'log_provider' )->write_log( 'proxyAmpError' );
				status_header( 503 );
				$this->end_connection();
			}
		}
	}

	protected function get_proxy_uri() {
		$uri_utils = Marfeel_Press_App::make( 'uri_utils' );
		$current_uri = $uri_utils->get_current_uri();
		$current_uri = $uri_utils->remove_protocol( $current_uri );
		$params = array();
		$qs = preg_replace( '/&?amp=1/', '', $_SERVER['QUERY_STRING'] );

		if ( ! empty( $qs ) ) {
			$params = explode( '&', $qs );
		}

		if ( $uri_utils->is_amp_uri( $current_uri ) ) {
			$current_uri = preg_replace( '/\/amp(\/)?$/', '$1', $current_uri );
			$path = '/amp/';
			$this->is_amp = true;
		} else {
			$path = '/';
			$params[] = 'marfeeldt=s';
		}

		$uri = $path . $current_uri;

		if ( ! empty( $params ) ) {
			$uri .= '?' . implode( '&', $params );
		}

		return $uri;
	}

	private function end_connection() {
		if ( ! defined( 'PHPUNIT_TEST' ) ) {
			exit;
		}
	}

	private function replace_meta_generator( $html ) {
		return preg_replace(
			'/<meta name=["\']?generator["\']? content=["\']?MarfeelGutenberg["\']?>/',
			'<meta name="generator" content="MarfeelPress">',
			$html
		);
	}
}
