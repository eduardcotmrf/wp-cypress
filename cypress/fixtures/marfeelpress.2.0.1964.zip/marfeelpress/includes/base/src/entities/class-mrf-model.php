<?php

namespace Base\Entities;

class Mrf_Model {

	/** @var string */
	public $version;

	/** @var string */
	public $custom_version;

	/** @var string */
	public $render_ui;

	/** @var string */
	public $include_details;

	/** @var string */
	public $include_mosaic;

	/** @var Mrf_section */
	public $section;

	/** @var string */
	public $marfeel_definition;

	/** @var string */
	public $theme;

	/** @var string */
	public $current_section_name;

	/** @var string */
	public $runtime_enviroment;

	/** @var Mrf_Item */
	public $item;

	/** @var Mrf_item */
	public $linked_item;

	/** @var string */
	public $sections_definitions;

	/** @var string */
	public $article_uri;

	/** @var string */
	public $sections;

	/** @var string */
	public $top_media;

	/** @var string */
	public $param;

	/** @var string */
	public $ui_features;

	/** @var string */
	public $navigation_level;
}
