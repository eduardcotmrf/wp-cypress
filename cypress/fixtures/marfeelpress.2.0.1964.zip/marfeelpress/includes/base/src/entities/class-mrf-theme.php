<?php

namespace Base\Entities;

class Mrf_Theme {

	/** @var string */
	public $name;

	/** @var string */
	public $device_type;

}
