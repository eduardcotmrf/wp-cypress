<?php

namespace Base\Entities\Settings;

abstract class Mrf_Tenant_Type {
	const ENTERPRISE = 'ENTERPRISE';
	const LONGTAIL = 'LONGTAIL';
}
