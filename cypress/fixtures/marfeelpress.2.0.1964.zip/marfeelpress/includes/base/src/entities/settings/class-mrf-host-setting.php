<?php

namespace Base\Entities\Settings;

use Base\Entities\Settings\Mrf_Setting;

class Mrf_Host_Setting extends Mrf_Setting {
	/** @var string */
	public $resources = '';

	/** @var string */
	public $home = '';

}
