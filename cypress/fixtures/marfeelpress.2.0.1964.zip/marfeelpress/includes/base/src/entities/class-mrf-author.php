<?php

namespace Base\Entities;

class Mrf_Author {

	/** @var string */
	public $name;

}
