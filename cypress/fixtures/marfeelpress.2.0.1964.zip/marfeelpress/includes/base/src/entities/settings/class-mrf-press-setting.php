<?php

namespace Base\Entities\Settings;

use Base\Entities\Settings\Mrf_Setting;
use Base\Entities\Settings\Mrf_Amp_Setting;
use Base\Entities\Settings\Mrf_Tenant_Type;

class Mrf_Press_Setting extends Mrf_Setting {

	/** @var int */
	public $mode;

	/** @var string */
	public $api_token;

	/** @var string */
	public $insight_token;

	/** @var string */
	public $tenant_type = Mrf_Tenant_Type::LONGTAIL;

	/**
	 * @var bool
	 * @jsonRemove
	 */
	public $mrf_router_active = true;

	/**
	 * @var bool
	 * @jsonRemove
	 */
	public $leroy_active = true;

	/**
	 * @var bool
	 * @jsonRemove
	 */
	public $cache_active;

	/**
	 * @var int
	 * @jsonRemove
	 */
	public $install_error = 0;

	/** @var bool */
	public $activated_once = false;

	/** @var string */
	public $media_group;

	/** @var string */
	public $availability;

	/** @var int */
	public $autoupdate = 1;

	/** @var int */
	public $error_reporting = 1;

	/** @var Base\Entities\Settings\Mrf_Amp_Setting */
	public $amp;

	/** @var string */
	public $home_name;

	/** @var bool */
	public $avoid_query_params;

	/** @var int */
	public $sections_step_status = 0;

	/** @var int */
	public $looknfeel_step_status = 0;

	/** @var string */
	public $plugin_status;

	/** @var bool */
	public $disable_multipage;

	/** @var string */
	public $producer_host;

	/** @var bool */
	public $pending_to_activate = false;

	/**
	 * @var array
	 * @jsonRemove
	 */
	public $versions = array(
		'MRFP_LEROY_BUILD_NUMBER' => 469,
	);

	public function __construct() {
		$this->amp = new Mrf_Amp_Setting();
	}
}
