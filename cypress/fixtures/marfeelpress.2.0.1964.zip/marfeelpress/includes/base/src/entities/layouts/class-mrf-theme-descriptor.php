<?php

namespace Base\Entities\Layouts;

class Mrf_Theme_Descriptor {

	/** @var int */
	public $max_articles;

	/** @var Base\Entities\Layouts\Mrf_Layout[] */
	public $layouts = array();

}
