<?php

namespace Base\Entities\Twister;

class Mrf_Twister {

	/**
	 * @var string
	 * @json businessModel
	 */
	public $business_model = "ENTERPRISE";

}
