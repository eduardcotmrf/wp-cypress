<?php

namespace Base\Entities;

class Mrf_Size {

	/** @var int */
	public $width;

	/** @var int */
	public $height;

}

