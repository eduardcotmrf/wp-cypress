<?php

namespace Base\Entities\Insight;

class Mrf_Menu {
	/**
	 * @var Base\Entities\Insight\Mrf_Section_Definitions[]
	 * @json sectionDefinitions
	 */
	public $section_definitions = array();
}
