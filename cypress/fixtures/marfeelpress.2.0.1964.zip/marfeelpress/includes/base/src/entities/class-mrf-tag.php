<?php

namespace Base\Entities;

class Mrf_Tag {

	/** @var string */
	public $name;

	/** @var string */
	public $content;

}

