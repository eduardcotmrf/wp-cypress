<?php
/**
 * Copyright (c) 2018 Marfeel Solutions (https://www.marfeel.com)
 * All Rights Reserved.*
 * NOTICE: All information contained herein is, and remains
 * the property of Marfeel Solutions S.L and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Marfeel Solutions S.L and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Marfeel Solutions S.L .
 */
namespace Base\Entities;

class Mrf_SignUp {

	/** @var string
	 * @json userEmail
	*/
	public $user_email;

	/** @var string
	 * @json marfeelEmail
	 * */
	public $marfeel_email;

	/** @var string
	 * @json firstName
	 * */
	public $first_name;

	/** @var string
	 * @json lastName
	 * */
	public $last_name;

	/** @var string
	 * @json tenantUri
	 * */
	public $tenant_uri;

	/** @var string */
	public $token;

}
