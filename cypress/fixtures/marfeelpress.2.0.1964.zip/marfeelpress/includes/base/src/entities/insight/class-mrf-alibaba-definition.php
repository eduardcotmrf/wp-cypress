<?php

namespace Base\Entities\Insight;

class Mrf_Alibaba_Definition {
	/** @var string */
	public $algorithm;
}
