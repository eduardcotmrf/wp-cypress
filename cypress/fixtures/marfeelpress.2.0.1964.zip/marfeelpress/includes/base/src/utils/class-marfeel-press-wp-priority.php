<?php

namespace Base\Utils;

class Marfeel_Press_WP_Priority {
	const HIGH = 9;
	const NORMAL = 10;
	const LOW = 11;
}
