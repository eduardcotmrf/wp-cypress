<?php


namespace Base\Utils;

use Ioc\Marfeel_Press_App;

class Uri_Utils {

	public function add_params( $url, $params ) {
		if ( is_array( $params ) ) {
			foreach ( $params as $param ) {
				$url = $this->add_params( $url, $param );
			}

			return $url;
		} else {
			if ( strpos( $url, '?' ) !== false ) {
				$params = preg_replace( '/\/?\?/', '&', $params );

				if ( ! empty( $params ) && $params[0] != '&' ) {
					$params = '&' . $params;
				}
			} else {
				$url    = rtrim( $url, '/' ) . '/';
				$params = ltrim( $params, '/' );

				if ( ! empty( $params ) && $params[0] == '&' ) {
					$params = '?' . substr( $params, 1 );
				}
			}

			return $url . $params;
		}
	}

	public function get_home_url() {
		$protocol = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] == 'on' ) ? 'https' : 'http';
		return $protocol . '://' . $_SERVER['HTTP_HOST'];
	}

	public function get_content( $uri ) {
		$response = wp_remote_get( $uri );

		return $response['body'];
	}

	public function get_absolute_uri( $uri ) {
		if ( strpos( $uri, 'http' ) === false ) {
			if ( substr( $uri, 0, 2 ) == '//' ) {
				$home_url = home_url();
				$uri = substr( $home_url, 0, strpos( $home_url, '://' ) ) . ':' . $uri;
			} elseif ( $uri == '/' ) {
				$uri = home_url( $uri );
			} elseif ( $uri[0] == '/' ) {
				$uri = home_url( ltrim( $uri, '/' ) );
			}
		}

		return $uri;
	}

	public function get_amp_uri( $uri ) {
		$permalink_structure = get_option( 'permalink_structure' );

		return empty( $permalink_structure ) ? $this->add_params( $uri, '&amp=1' ) : rtrim( $uri, '/' ) . '/amp/';
	}

	public function get_current_uri() {
		$structure   = get_option( 'permalink_structure' );

		if ( empty( $structure ) ) {
			$current_url = $_SERVER['REQUEST_URI'];
		} else {
			$current_url = str_replace( '?' . $_SERVER['QUERY_STRING'] , '', $_SERVER['REQUEST_URI'] );
		}

		$current_url = $this->get_absolute_uri( $current_url );

		$host = wp_parse_url( $current_url, PHP_URL_HOST );
		$tenant_home = Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' );

		if ( $host != $tenant_home ) {
			$current_url = str_replace( $host, $tenant_home, $current_url );
		}

		return $current_url;
	}

	public function is_local( $uri ) {
		return ( strpos( $uri, 'localhost' ) !== false );
	}

	public function is_amp_uri( $uri ) {
		return preg_match( '/\/amp\/?$/', $uri ) || isset( $_GET['amp'] ) && $_GET['amp'] == 1;
	}

	public function is_site_secure() {
		return ( ! empty( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off' ) || $_SERVER['SERVER_PORT'] == 443;
	}

	public function is_feed() {
		return get_query_var( 'feed' ) == 'feed';
	}

	public function remove_protocol( $uri ) {
		return preg_replace( '/https?:\/\//', '', $uri );
	}
}
