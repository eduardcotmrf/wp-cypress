<?php

namespace Base;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Uninstaller {
	const OPTION_PLUGIN_STATUS = 'marfeel_press.plugin_status';

	public function uninstall() {
		$this->track_uninstall();
	}

	protected function track_uninstall() {
		$tracker = Marfeel_Press_App::make( 'tracker' );
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		$settings_service->set( self::OPTION_PLUGIN_STATUS, 'UNINSTALLED' );
		$tracker->identify( true );
		$tracker->track( 'plugin/uninstall' );
	}
}
