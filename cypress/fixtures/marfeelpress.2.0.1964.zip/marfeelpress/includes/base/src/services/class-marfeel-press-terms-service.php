<?php

namespace Base\Services;

use Ioc\Marfeel_Press_App;
use Base\Entities\Mrf_Tag;

class Marfeel_Press_Terms_Service {

	public function add_items_terms( $items ) {
		$ids = array_map( function( $item ) {
			return $item->id;
		}, $items );

		$results = Marfeel_Press_App::make( 'terms_repository' )->get_terms_by_post_ids( $ids );

		$terms = array();
		foreach ( $results as $result ) {
			$terms[ $result->object_id ][ $result->taxonomy ][] = $result;
		}

		foreach ( $items as $item ) {
			if ( isset( $terms[ $item->id ] ) ) {
				if ( isset( $terms[ $item->id ]['category'] ) ) {
					$item->categories = $terms[ $item->id ]['category'];
				}

				$mrf_tags = array();

				if ( isset( $terms[ $item->id ]['post_tag'] ) ) {
					foreach ( $terms[ $item->id ]['post_tag'] as $tag ) {
						$mrf_tag = new Mrf_Tag();

						$mrf_tag->name = $tag->name;
						$mrf_tag->content = get_term_link( $tag, 'post_tag' );

						$mrf_tags[] = $mrf_tag;
					}
				}

				$item->detail_item->pocket['tags'] = $mrf_tags;
			}
		}
	}
}
