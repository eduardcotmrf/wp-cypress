<?php

namespace Base\Services;

use WPSEO_Options;
use WPSEO_OpenGraph;
use Ioc\Marfeel_Press_App;
use Wa72\HtmlPageDom\HtmlPage;

class Marfeel_Press_Head_Service {

	const WP_HEAD = "wp_head";
	const HTML = "html";
	const DOMELEMENT_TYPE = 1;

	/** @var string */
	public static $head;

	public function extract_metadata( $object ) {
		$this->prepare_head();
		$default_title = wp_title( '-', false );
		$object->tag_information->html = $this->get_head();
		$parser = new HtmlPage( $object->tag_information->html );

		if ( $parser->filter( 'title' )->count() ) {
			$title = $parser->filter( 'title' )->text();

			if ( $title === get_option( 'blogname' ) ) {
				$title = get_option( 'blogname' ) . ' - ' . get_option( 'blogdescription' );
			}

			$object->tag_information->add_tag( 'TITLE', $title );
			$object->tag_information->html = $this->remove_title( $object->tag_information->html );
		} else {
			$object->tag_information->add_tag( 'TITLE', $default_title );
		}

		$parser->filter( 'meta' )->each( function( $meta ) use ( $object ) {
			$attributes = array();
			foreach ( $meta->getNode( 0 )->attributes as $attr ) {
				$attributes[ $attr->name ] = $attr->value;
			}
			$object->tag_information->add_tag( 'META', null, $attributes );
		} );

		$parser->filter( 'link[rel="next"],link[rel="prev"]' )->each( function( $link ) use ( $object ) {
			$attributes = array();
			foreach ( $link->getNode( 0 )->attributes as $attr ) {
				$attributes[ $attr->name ] = $attr->value;
			}
			$object->tag_information->add_tag( 'LINK', null, $attributes );
		} );

	}

	public function capture_head() {
		add_action( self::WP_HEAD, function() {
			ob_start();
		}, 0);

		add_action( self::WP_HEAD, function() {
			Marfeel_Press_Head_Service::$head = ob_get_clean();
		}, PHP_INT_MAX);
	}

	public function get_head() {
		ob_start();

		apply_filters( self::WP_HEAD, self::$head );

		$head = ob_get_clean();

		return strlen( $head ) > strlen( self::$head ) ? $head : self::$head;
	}

	protected function remove_title( $head ) {
		return preg_replace( '/<title>.*?<\/title>/i', '', $head );
	}

	public function add_marfeelgarda_if_needed() {
		add_action( 'wp_head', function() {
			if ( $this->needs_garda() ) {
				$this->add_marfeelgarda();
			}
		}, 0 );
	}

	private function needs_garda() {
		return ! Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.mrf_router_active' )
				&& ! is_admin()
				&& ! defined( 'REST_REQUEST' );
	}

	private function add_marfeelgarda() {
		$host = Marfeel_Press_App::make( 'definition_service' )->get( 'user_interface.resources_host' );
		$host = Marfeel_Press_App::make( 'uri_utils' )->remove_protocol( $host );

		include_once MRFP__MARFEEL_PRESS_DIR . 'includes/base/src/templates/marfeelgarda.php';
	}

	public function add_gardac_press() {
		$url = Marfeel_Press_App::make( 'definition_service' )->get( 'user_interface.resources_host' )
		   . '/statics/marfeel/gardacpress.js';
		echo '<script src="' . $url . '"></script>';
	}

	protected function prepare_head() {
		if ( $this->is_yoast_seo_activated() ) {
			$this->prepare_yoast_seo();
		}
	}

	protected function prepare_yoast_seo() {
		$options = WPSEO_Options::get_option( 'wpseo_social' );
		if ( $options['twitter'] === true ) {
			add_action( 'wpseo_head', array( 'WPSEO_Twitter', 'get_instance' ), 40 );
		}

		if ( $options['opengraph'] === true ) {
			$GLOBALS['wpseo_og'] = new WPSEO_OpenGraph();
		}
	}

	protected function is_yoast_seo_activated() {
		return class_exists( 'WPSEO_Options' );
	}

}
