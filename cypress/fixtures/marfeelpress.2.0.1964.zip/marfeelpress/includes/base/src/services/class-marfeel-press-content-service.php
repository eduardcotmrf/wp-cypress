<?php

namespace Base\Services;

class Marfeel_Press_Content_Service {

	private function disable_content_output() {
		add_filter('the_content', function( $content ) {
			ob_start();
			return $content;
		}, 0);
		add_filter('the_content', function( $content ) {
			ob_end_clean();
			return $content;
		}, PHP_INT_MAX);
	}

	public function get_post_content( $item ) {
		$this->disable_content_output();
		add_filter( 'the_content', array( $this, 'parse_content' ), 12, 2 );

		return apply_filters( 'the_content', get_post()->post_content, $item );
	}

	public function parse_content( $content, $item = null ) {
		if ( $item ) {
			$content = $this->clean_duplicated_top_media( $content, $item );
		}

		return $content;
	}

	protected function clean_duplicated_top_media( $content, $item ) {
		$top_media_url = basename( $item->media->src );

		$content = preg_replace( '/<img [^>]+' . $top_media_url . '[^>]+>/i', '', $content );

		return $content;
	}
}
