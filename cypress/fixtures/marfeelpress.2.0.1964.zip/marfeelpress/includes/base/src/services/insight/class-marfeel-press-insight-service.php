<?php


namespace Base\Services\Insight;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Insight_Service {
	public function get_base_api() {
		$tenant_home = Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' );
		$base_url = Marfeel_Press_App::make( 'request_utils' )->is_dev() && $_SERVER['HTTP_HOST'] == MRF_DEV_DOMAIN ? MRFP_DEV_INSIGHT_API : MRFP_INSIGHT_API;

		return $base_url . '/tenants/' . preg_replace( '/^www\./i', '', $tenant_home );
	}
}
