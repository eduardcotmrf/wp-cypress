<?php

namespace Base\Services;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_WP_Service {

	public function load_url( $url ) {
		error_reporting( E_WARNING ); // @codingStandardsIgnoreLine

		$_SERVER['REQUEST_URI'] = $url;

		Marfeel_Press_App::make( 'head_service' )->capture_head();

		global $wp;
		$wp->main();
	}
}
