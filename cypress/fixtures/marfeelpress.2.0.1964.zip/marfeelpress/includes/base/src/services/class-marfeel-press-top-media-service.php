<?php

namespace Base\Services;

use Base\Marfeel_Press_Plugin_Conflict_Manager;
use Base\Entities\Mrf_Media;
use Base\Utils\Image_Utils;
use Ioc\Marfeel_Press_App;

class Marfeel_Press_Top_Media_Service {

	const MIN_IMG_WIDTH = 450;
	const RATIO_RANGE = 0.1;

	/** @var Image_Utils */
	private $image_utils;

	public function __construct() {
		$this->image_utils = Marfeel_Press_App::make( 'image_utils' );
	}

	protected function is_similar_ratio( $ratio, $size ) {
		$size_ratio = $size['width'] / $size['height'];

		return $size_ratio >= $ratio - self::RATIO_RANGE && $size_ratio <= $ratio + self::RATIO_RANGE;
	}

	protected function get_media( $ids ) {
		$results = Marfeel_Press_App::make( 'posts_repository' )->get_top_media( $ids );

		$images = array();
		foreach ( $results as $result ) {
			$meta = unserialize( $result->meta_value ); // @codingStandardsIgnoreLine
			$media = new Mrf_Media();
			$media->caption = $result->post_excerpt;

			if ( isset( $meta['image_meta'] ) ) {
				$media->caption = $meta['image_meta']['caption'];
			}

			$image = wp_get_attachment_image_src( $result->ID, 'full', false );

			list( $media->src, $media->width, $media->height ) = $image;

			$media->src = Marfeel_Press_App::make( 'uri_utils' )->get_absolute_uri( $media->src );

			$media->src = Marfeel_Press_Plugin_Conflict_Manager::get_modified_image_url( $media->src );

			$images[ $result->post_id ] = $media;
		}

		return $images;
	}

	public function get_top_media() {
		global $post;
		$medias = $this->get_media( array( $post->ID ) );

		if ( isset( $medias[ $post->ID ] ) ) {
			return $medias[ $post->ID ];
		}

		return null;
	}

	public function get_items_top_media( $items ) {
		$ids = array();

		foreach ( $items as $item ) {
			if ( $item->media->src === null ) {
				$ids[] = $item->id;
			}
		}

		$images = $this->get_media( $ids );

		foreach ( $items as $item ) {
			if ( isset( $images[ $item->id ] ) ) {
				$item->media = $images[ $item->id ];
			} else {
				$item->media = null;
			}

			if ( $item->media ) {
				$item->media->image_ratio = $this->image_utils->calculate_image_ratio( $item->media->width, $item->media->height );
			}
		}
	}
}
