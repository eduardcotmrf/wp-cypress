<?php

namespace Base\Descriptor\Parser;

interface Parser {

	public function parse($content);
}
