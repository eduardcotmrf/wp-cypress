<?php

namespace Base\Descriptor\Reader;

interface Reader {

	public function read();
}
