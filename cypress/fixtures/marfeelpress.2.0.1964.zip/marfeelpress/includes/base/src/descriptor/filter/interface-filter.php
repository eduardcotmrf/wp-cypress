<?php

namespace Base\Descriptor\Filter;

interface Filter {

	public function should_add( $layout );
}
