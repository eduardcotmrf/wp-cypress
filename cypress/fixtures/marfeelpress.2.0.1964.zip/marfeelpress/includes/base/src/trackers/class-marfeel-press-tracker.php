<?php

namespace Base\Trackers;

use Ioc\Marfeel_Press_App;

// @codingStandardsIgnoreStart WordPress.NamingConventions.ValidVariableName.NotSnakeCase
class Marfeel_Press_Tracker {
	const ACCOUNT = 'CeAIeBXqVRVRYumjvBSeiO3KEB1NKaHd';
	const OPTION_TENANT_TYPE = 'marfeel_press.tenant_type';
	const OPTION_MEDIA_GROUP = 'marfeel_press.media_group';
	const OPTION_PLUGIN_STATUS = 'marfeel_press.plugin_status';
	const OPTION_TENANT_HOME = 'tenant_home';
	const OPTION_AVAILABILITY = 'mrf_availability';
	const OPTION_ADS_TXT_STATUS = 'ads.ads_txt.status';
	const EVENTS_TO_SALESFORCE = 'step/marfeel/activate|plugin/install|marfeel/deactivated|plugin/uninstall';

	/** @var string */
	private $tenant;

	public function __construct() {
		$Analytics = Marfeel_Press_App::make( 'Analytics' );

		$this->tenant = $_SERVER['HTTP_HOST'];
		$Analytics::init(self::ACCOUNT);
	}

	public function track( $action, $data = array() ) {
		$Analytics = Marfeel_Press_App::make( 'Analytics' );
		$definition_service = Marfeel_Press_App::make( 'definition_service' );

		$tenant_home = $definition_service->get( self::OPTION_TENANT_HOME );

		$Analytics::track(array(
			'userId' => $tenant_home,
			'event' => $action,
			'properties' => $data,
			'integrations' => array(
				'Salesforce' => $this->is_sendeable_to_salesforce($action),
			),
		));
	}

	public function identify($sendSalesForce = false) {
		$Analytics = Marfeel_Press_App::make( 'Analytics' );
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$definition_service = Marfeel_Press_App::make( 'definition_service' );

		$tenant_type = $settings_service->get( self::OPTION_TENANT_TYPE );
		$media_group = $settings_service->get( self::OPTION_MEDIA_GROUP );
		$plugin_status = $settings_service->get( self::OPTION_PLUGIN_STATUS );
		$availability = $settings_service->get_option_data( self::OPTION_AVAILABILITY, 'OFF' );
		$tenant_home = $definition_service->get( self::OPTION_TENANT_HOME );
		$adstxt_status = $settings_service->get( self::OPTION_ADS_TXT_STATUS );
		$user = wp_get_current_user();

		$identification = array(
			'userId' => $tenant_home,
			'traits' => array(
				'email' => $user->user_email,
				'tenant_type' => $tenant_type,
				'plugin_version' => MRFP_MARFEEL_PRESS_BUILD_NUMBER,
				'plugin_status' => $plugin_status,
				'ads_txt_status' => $adstxt_status,
				'mrf_active' => $availability,
				'company' => array(
					'name' => ! empty( $media_group ) ? $media_group : $tenant_home,
				),
			),
			'integrations' => array(
				'Salesforce' => $sendSalesForce,
			),
		);

		if($sendSalesForce) {
			$identification['traits']['LeadSource'] = 'Segment';
		}

		$marfeel_status = $this->get_marfeel_status($plugin_status, $availability);
		if($marfeel_status) {
			$identification['traits']['marfeel_status'] = $marfeel_status;
		}

		$Analytics::identify( $identification );
	}

	public function get_configuration() {
		$definition_service = Marfeel_Press_App::make( 'definition_service' );
		$user = wp_get_current_user();

		$tenant_home = $definition_service->get( self::OPTION_TENANT_HOME );

		return array(
			'account' => self::ACCOUNT,
			'id' => $tenant_home,
			'user' => array(
				'email' => $user->user_email,
			),
		);
	}

	public function is_sendeable_to_salesforce($event) {
		return in_array($event, explode('|', self::EVENTS_TO_SALESFORCE));
	}

	public function get_marfeel_status($plugin_status, $mrf_active) {
		$marfeel_status = false;
		if($plugin_status == 'INSTALLED' && ($mrf_active == 'OFF' || $mrf_active == 'LOGGED')) {
			$marfeel_status = 'INSTALLED';
		} elseif($plugin_status == 'INSTALLED' && $mrf_active == 'ALL') {
			$marfeel_status = 'ACTIVATED';
		} elseif($plugin_status == 'DEACTIVATED' || $plugin_status == 'UNINSTALLED') {
			$marfeel_status = $plugin_status;
		}
		return $marfeel_status;
	}
}
// @codingStandardsIgnoreEnd WordPress.NamingConventions.ValidVariableName.NotSnakeCase
