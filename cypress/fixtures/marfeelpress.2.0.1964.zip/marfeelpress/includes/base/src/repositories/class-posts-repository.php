<?php

namespace Base\Repositories;

class Posts_Repository extends Repository {

	protected function build_posts_query( $filters ) {
		$wp_posts = $this->db->get_posts_table_name();

		$exclude = $filters['exclude'];
		unset( $filters['exclude'] );

		$limit = $filters['numberposts'];
		unset( $filters['numberposts'] );

		$wheres = array();
		foreach ( $filters as $key => $value ) {
			$wheres[] = "$key = '$value'";
		}

		$sql = "SELECT p.ID FROM $wp_posts p WHERE " . implode( ' AND ', $wheres );

		if ( ! empty( $exclude ) ) {
			$sql .= " AND p.ID NOT IN ( $exclude )";
		}

		return $sql . " ORDER BY post_date DESC LIMIT $limit";
	}

	public function get_latest_posts( $filters ) {
		$sql = $this->build_posts_query( $filters );

		$ids = array_map( function( $row ) {
			return $row->ID;
		}, $this->db->get_results( $sql ) );

		return get_posts( array(
			'include' => implode( ', ', $ids ),
		) );
	}

	public function get_top_media( $ids ) {
		$wp_posts = $this->db->get_posts_table_name();
		$wp_postmeta = $this->db->get_postmeta_table_name();

		return $this->db->get_results( "
			SELECT p.ID, p.guid, pmi.meta_value, pm.post_id, p.post_excerpt
			FROM $wp_posts p
				INNER JOIN $wp_postmeta pm ON pm.meta_value = p.ID
					AND pm.meta_key = '_thumbnail_id'
					AND pm.post_id IN (" . implode( ', ', $ids ) . ")
				INNER JOIN $wp_postmeta pmi ON pmi.post_id = p.ID
					AND pmi.meta_key = '_wp_attachment_metadata'
		" );
	}
}
