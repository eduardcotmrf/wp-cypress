<?php

namespace Base;
/**
 * Main activation class
 *
 * @package marfeel-press
 */

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Activator {

	const OPTION_API_TOKEN = 'marfeel_press.api_token';
	const OPTION_INSIGHT_TOKEN = 'marfeel_press.insight_token';
	const OPTION_PLUGIN_STATUS = 'marfeel_press.plugin_status';

	public function set_wp_token() {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$token = $settings_service->get( self::OPTION_API_TOKEN );

		if ( ! $token ) {
			$new_token = wp_generate_password( 16, false );
			$settings_service->set( self::OPTION_API_TOKEN, $new_token );
		}
	}

	public function activate() {
		Marfeel_Press_App::make( 'error_handler' );

		$this->create_marfeel_role();
		$this->set_wp_token();
		$this->insight_signup();
		$this->track_activation();
		$this->set_activated_once();
		$this->configure_ads_txt();

		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$availability = $settings_service->get_availability();
		$activated_once = $settings_service->get( 'marfeel_press.activated_once' );
		if ( $availability != 'ALL' && $availability != 'LOGGED' ) {
			$this->check_repository_environment();
		}

		if ( $activated_once ) {
			Marfeel_Press_App::make( 'mrf_insight_invalidator_service' )->invalidate_all();
		}

		Marfeel_Press_App::make( 'press_service' )->flush_url_cache();

		// Set transient for Activation
		set_transient( 'mrf_activation_redirect', true, 30 );
	}

	public function check_repository_environment() {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		if ( Marfeel_Press_App::make( 'activation_checker' )->is_prod_ready( $_SERVER['HTTP_HOST'] , MRFP_BLG_RESOURCES_HOST ) ) {
			$settings_service->set( 'marfeel_press.producer_host', MRFP_HUBBLGP_API );
			$settings_service->set( 'user_interface.resources_host', MRFP_BLG_RESOURCES_HOST );
		} else {
			$settings_service->set( 'marfeel_press.producer_host', MRFP_HUBPROP_API );
			$settings_service->set( 'user_interface.resources_host', MRFP_PRO_RESOURCES_HOST );
		}
	}

	protected function create_marfeel_role() {
		$capabilities = array(
			'activate_plugins' => true,
			'edit_theme_options' => true,
			'manage_options' => true,
			'read' => true,
			'install_plugins' => true,
			'upload_plugins' => true,
			'delete_plugins' => true,
			'update_plugins' => true,
			'upload_files' => true,
		);

		if ( get_role( 'marfeel' ) ) {
			remove_role( 'marfeel' );
		}

		add_role( 'marfeel', 'Marfeel User', $capabilities );
	}

	protected function create_and_register_menu( $menu_name, $menu_location ) {
		if ( ! has_nav_menu( $menu_location ) ) {
			$menu_id = $this->create_menu( $menu_name );
			$this->register_menu( $menu_location, $menu_id );
		}
	}

	protected function create_menu( $menu_name ) {
		$menu_name = 'Marfeel ' . $menu_name . ' Menu';
		$menu_exists = wp_get_nav_menu_object( $menu_name );
		if ( ! $menu_exists ) {
			return wp_create_nav_menu( $menu_name );
		}
		return $menu_exists->term_id;
	}

	protected function register_menu( $key, $menu_id ) {
		$this->locations[ $key ] = $menu_id;
	}

	protected function insight_signup() {
		$insight_signup = Marfeel_Press_App::make( 'insight_signup_service' );
		$error_utils = Marfeel_Press_App::make( 'error_utils' );

		$response = $insight_signup->signup();

		if ( is_wp_error( $response ) ) {
			if ( $response->get_error_message( 'invalid_fields' ) !== 'marfeel_user' ) {
				$this->mrf_set_error();
			}
		} elseif ( $error_utils->is_error_response( $response ) ) {
			$this->mrf_set_error();
		}
	}

	protected function mrf_set_error() {
		set_transient( 'signup_error', true );
	}

	protected function track_activation() {
		$tracker = Marfeel_Press_App::make( 'tracker' );
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		$settings_service->set( self::OPTION_PLUGIN_STATUS, 'INSTALLED' );
		$tracker->identify( true );
		$tracker->track( 'plugin/install' );
	}

	protected function set_activated_once(){
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$availability = $settings_service->get_availability();

		if ( $availability == 'ALL' ) {
			$settings_service->set( 'marfeel_press.activated_once', true );
		}
	}

	protected function configure_ads_txt() {
		Marfeel_Press_App::make( 'ads_txt_plugin_support' )
			->save_mrf_lines( is_plugin_active( 'ads-txt/ads-txt.php' ) );
	}
}
