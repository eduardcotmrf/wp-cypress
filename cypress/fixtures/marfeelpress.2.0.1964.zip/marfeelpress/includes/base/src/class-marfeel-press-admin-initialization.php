<?php

namespace Base;
use Base\Entities\Settings\Mrf_Tenant_Type;
use Ioc\Marfeel_Press_App;
/**
 * Admin activation class
 *
 * @package marfeel-press
 */

class Marfeel_Press_Admin_Initialization {

	public function redirect_if_activation() {
		if ( ! get_transient( 'mrf_activation_redirect' ) ) {
			return;
		}

		delete_transient( 'mrf_activation_redirect' );

		if ( is_network_admin() || isset( $_GET['activate-multi'] ) ) {
			return;
		}

		$tenant_type = Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.tenant_type' );
		$target_page = $tenant_type == Mrf_Tenant_Type::LONGTAIL ? 'onboarding' : 'mrf-settings';

		wp_safe_redirect( add_query_arg( array(
			'page' => $target_page,
		), admin_url( 'admin.php' ) ) );

	}

}
