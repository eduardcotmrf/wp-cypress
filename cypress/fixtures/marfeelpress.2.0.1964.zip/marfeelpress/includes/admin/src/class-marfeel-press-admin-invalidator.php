<?php

namespace Admin;

use Ioc\Marfeel_Press_App;


class Marfeel_Press_Admin_Invalidator {

	/** @var Marfeel_Press_Before_Saving_Post_Info */
	public $temporary_post_info;

	public function invalidate_post( $post_id ) {
		if ( isset( get_post( $post_id )->post_type ) && get_post( $post_id )->post_type == Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ) && get_post_status( $post_id ) == 'publish' ) {
			return Marfeel_Press_App::make( 'mrf_insight_invalidator_service' )->invalidate_post( get_post( $post_id ) );
		}
	}

	public function save_post_data_pre_update( $post_id, $data ) {
		if ( isset( $data['post_type'] ) && $data['post_type'] == Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ) ) {
			$this->temporary_post_info = new Marfeel_Press_Before_Saving_Post_Info();
			$this->temporary_post_info->permalink = get_permalink( $post_id );
			$this->temporary_post_info->title = $data['post_title'];
			$this->temporary_post_info->except = $data['post_excerpt'];
			$this->temporary_post_info->categories = get_the_category( $post_id );
			return true;
		}
		return false;
	}

	public function invalidate_section( $post_id, $post_after, $post_before ) {
		if ( isset( $post_after->post_type ) && $post_after->post_type == Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ) && get_post_status( $post_id ) == 'publish' ) {
			$sections_to_invalidate = get_the_category( $post_id );

			return Marfeel_Press_App::make( 'mrf_insight_invalidator_service' )->invalidate_section_array( $sections_to_invalidate );
		}

		return null;
	}

}

