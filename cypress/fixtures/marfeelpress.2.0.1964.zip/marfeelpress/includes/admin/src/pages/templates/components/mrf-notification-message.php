<div class="mrf-notification-message toast fade-left-leave-active" toggle="fade-left-leave-to" style="display: <?php echo $context->toast_display; ?>;">
	<span class="mrf-icon <?php echo $context->variant; ?> ml-3"></span>
	<div class="toast-message px-2"><?php echo $context->message_txt; ?></div>
	<span class="btn mrf-icon mrf-icon__close--default" onclick="hide()"></span>
	</button>
</div>

<script>
function hide() {
	var el = document.querySelector('.mrf-notification-message');
	el.style.display = 'none';
}

function autoHide() {
	setTimeout(hide, 5000);
}

autoHide();

</script>
