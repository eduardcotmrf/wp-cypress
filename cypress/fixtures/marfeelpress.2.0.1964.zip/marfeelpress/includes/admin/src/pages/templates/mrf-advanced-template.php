<div class="p-5">
	<h5 class="section-title"><?php echo $context->title; ?></h5>
	<hr class="mb-5">

	<form method="post" action="">
		<input type="hidden" name="is-dev" value="<?php echo $context->is_dev ? 1 : 0; ?>">
		<input type="hidden" name="ok" value="1">
		<div class="form-group row">
			<label for="resources-host" class="col-4 col-form-label text-right">
				Choose who can see the marfeelized version
			</label>
			<div class="col-6">
				<?php
					foreach ( $context->options as $option ) {
						$checked = $context->selected_availability == $option['mode'] ? 'checked' : '';
						echo '<div class="custom-control custom-radio">';
							echo '<input type="radio" id="activation-mode-' . $option['mode'] . '" name="availability" class="custom-control-input" ' . $checked . ' value="' . $option['mode'] . '">';
							echo '<label class="custom-control-label" for="activation-mode-' . $option['mode'] . '">' . $option['mode'] . '. <span class="text-muted">' . $option['description'] . '</span></label>';
						echo '</div>';
					}
				?>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<div class="custom-control custom-checkbox custom-control-inline">
					<input type="hidden" name="amp" value="0">
					<input type="checkbox" class="custom-control-input" name="amp" id="amp"
						<?php echo $context->amp ? 'checked' : ''; ?> value="1">
					<label class="custom-control-label" for="amp"><?php echo trans( 'activate.amp' ); ?></label>
				</div>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<div class="custom-control custom-checkbox custom-control-inline">
					<input type="checkbox" class="custom-control-input" name="mrf_router" id="mrf_router"
						<?php echo $context->mrf_router ? 'checked' : ''; ?> value="1">
					<label class="custom-control-label" for="mrf_router"><?php echo trans( 'activate.mrf_router' ); ?></label>
				</div>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<div class="custom-control custom-checkbox custom-control-inline">
					<input type="checkbox" class="custom-control-input" name="cache" id="cache"
						<?php echo $context->cache ? 'checked' : ''; ?> value="1">
					<label class="custom-control-label" for="cache"><?php echo trans( 'activate.cache' ); ?></label>
				</div>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<div class="custom-control custom-checkbox custom-control-inline">
					<input type="checkbox" class="custom-control-input" name="autoupdate" id="autoupdate"
						<?php echo $context->autoupdate ? 'checked' : ''; ?> value="1">
					<label class="custom-control-label" for="autoupdate"><?php echo trans( 'autoupdate' ); ?></label>
				</div>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<div class="custom-control custom-checkbox custom-control-inline">
					<input type="checkbox" class="custom-control-input" name="error-reporting" id="error-reporting"
						<?php echo $context->error_reporting ? 'checked' : ''; ?> value="1">
					<label class="custom-control-label" for="error-reporting"><?php echo trans( 'error_reporting' ); ?></label>
				</div>
			</div>
		</div>

		<div class="form-group row">
			<label for="post-type" class="col-4 col-form-label text-right">
				<?php echo trans( 'post_type' ); ?>
			</label>
			<div class="col-6">
				<select name="post-type" class="form-control">
					<?php foreach ( $context->post_types as $type ) { ?>
						<option value="<?php echo $type; ?>"<?php echo $context->post_type == $type ? ' selected="selected"' : ''; ?>><?php echo $type; ?></option>
					<?php } ?>
				</select>
			</div>
		</div>

		<div class="form-group row">
			<div class="col-6 offset-4">
				<button class="insight-token-field btn btn-link" type="button" onclick="jQuery('.insight-token-field').toggle();" ><?php echo trans( 'insight_token.show' ); ?></button>
			</div>
		</div>

		<div class="insight-token-field hidden">
			<div class="form-group row ">
				<label for="insight-token" class="align-items-center col-4 col-form-label d-flex justify-content-end">
					<?php echo trans( 'insight_token.label' ); ?>
				</label>
				<div class="col-6">
					<input type="text" name="insight-token" class="form-control" value="<?php echo $context->insight_token; ?>" />
				</div>
				<button class="btn btn-link" type="button" onclick="jQuery('.insight-token-field').toggle();" ><?php echo trans( 'insight_token.hide' ); ?></button>
			</div>
		</div>
		<?php if ( $context->is_dev ) { ?>
			<div class="form-group row">
				<div class="col-6 offset-4">
					<button class="btn btn-warning" name="reset-version">Update Leroy Version</button>
				</div>
			</div>
			<div class="form-group row">
				<label for="resources-host" class="col-4 col-form-label text-right">
					Resources host
				</label>
				<div class="col-6">
					<input type="text" name="resources-host" class="form-control" value="<?php echo $context->resources_host; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="producers-host" class="col-4 col-form-label text-right">
					Producer host
				</label>
				<div class="col-6">
					<input type="text" name="producer-host" class="form-control" value="<?php echo $context->producer_host; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="tenant-home" class="col-4 col-form-label text-right">
					Tenant name
				</label>
				<div class="col-6">
					<input type="text" name="tenant-home" class="form-control" value="<?php echo $context->tenant_home; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="tenant-uri" class="col-4 col-form-label text-right">
					Tenant uri
				</label>
				<div class="col-6">
					<input type="text" name="tenant-uri" class="form-control" value="<?php echo $context->tenant_uri; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="tenant-type" class="col-4 col-form-label text-right">
					Tenant type
				</label>
				<div class="col-6">
					<input type="text" name="tenant-type" class="form-control" value="<?php echo $context->tenant_type; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="media-group" class="col-4 col-form-label text-right">
					Media Group
				</label>
				<div class="col-6">
					<input type="text" name="media-group" class="form-control" value="<?php echo $context->media_group; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="marfeel-sw-name-id" class="col-4 col-form-label text-right">
					Marfeel sw name
				</label>
				<div class="col-6">
					<input type="text" name="marfeel-sw-name-id" class="form-control" value="<?php echo $context->marfeel_sw_name_id; ?>" />
				</div>
			</div>
			<div class="form-group row">
				<label for="resources-host" class="col-4 col-form-label text-right">
					API Token
				</label>
				<div class="col-6">
					<input type="text" name="api-token" class="form-control" value="<?php echo $context->api_token; ?>" />
				</div>
			</div>
			<?php if ( ! $context->is_longtail ) { ?>
				<div class="form-group row">
					<div class="col-6 offset-4">
						<div class="custom-control custom-checkbox custom-control-inline">
							<input type="checkbox" class="custom-control-input" name="leroy" id="leroy"
								<?php echo $context->leroy ? 'checked' : ''; ?> value="1">
							<label class="custom-control-label" for="leroy"><?php echo trans( 'activate.leroy' ); ?></label>
						</div>
					</div>
				</div>
			<?php } ?>
			<?php if ( ! empty( $context->permalink_structure ) ) { ?>
				<div class="form-group row">
					<div class="col-6 offset-4">
						<div class="custom-control custom-checkbox custom-control-inline">
							<input type="checkbox" class="custom-control-input" name="avoid-query" id="avoid_query_params"
								<?php echo $context->avoid_query_params ? 'checked' : ''; ?> value="1">
							<label class="custom-control-label" for="avoid_query_params">Avoid query params usage</label>
						</div>
					</div>
				</div>
			<?php } ?>
			<div class="form-group row">
				<div class="col-6 offset-4">
					<div class="custom-control custom-checkbox custom-control-inline">
						<input type="checkbox" class="custom-control-input" name="disable-multipage" id="disable_multipage"
							<?php echo $context->disable_multipage ? 'checked' : ''; ?> value="1">
						<label class="custom-control-label" for="disable_multipage">Disable multipage</label>
					</div>
				</div>
			</div>
			<div class="form-group row">
				<label for="mrf-console-log" class="col-4 text-right">Logs</label>
				<div class="col-7">
					<textarea id="mrf-console-log" class="form-control" rows="10" cols="100" readonly>
					</textarea>
				</div>
			</div>
			<div class="row mb-5">
				<label class="control-label text-right col-4">
					factory reset
				</label>
				<div class="col-6">
					<button type="submit" name="reset" value="1" class="btn btn-danger">Reset</button>
				</div>
			</div>
			<?php if ( $context->is_longtail ) { ?>
			<div class="form-group row">
				<div class="col-6 offset-4">
					<div class="custom-control custom-checkbox custom-control-inline">
						<input type="checkbox" class="custom-control-input" name="move-to-enterprise" id="move_to_enterprise"
							checked value="1">
						<label class="custom-control-label" for="move_to_enterprise">Move this tenant to ENTERPRISE</label>
					</div>
				</div>
			</div>
			<?php } ?>

		<?php } ?>
		<div class="row">
			<div class="col-11 text-right">
				<button type="submit" class="btn btn-success">Save changes</button>
			</div>
		</div>
	</form>
</div>

<?php require_once( MRFP__MARFEEL_PRESS_ADMIN_TEMPLATES_DIR . 'components/mrf-notification-message.php' ); ?>
