<?php


namespace Admin\Pages;

use Ioc\Marfeel_Press_App;
use Base\Entities\Settings\Mrf_Availability_Modes_Enum;
use Base\Utils\Http_Client;

class Page_Utils {
	const OPTION_AVAILABILITY = 'mrf_availability';
	const OPTION_AMP = 'marfeel_press.amp.activate';
	const OPTION_ACTIVATED_ONCE = 'marfeel_press.activated_once';
	const OPTION_ROUTER_ACTIVE = 'marfeel_press.mrf_router_active';

	private function track_activation() {
		$tracker = Marfeel_Press_App::make( 'tracker' );

		$tracker->identify( true );
		$tracker->track( 'step/marfeel/activate' );
	}

	public function activate_all( $amp = true ) {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$press_service = Marfeel_Press_App::make( 'press_service' );
		$settings_service->set_option_data( self::OPTION_AVAILABILITY, Mrf_Availability_Modes_Enum::ALL );
		$settings_service->set( self::OPTION_AMP, $amp );
		$this->track_activation();
		$press_service->flush_url_cache();

		if ( $settings_service->get( self::OPTION_ACTIVATED_ONCE ) !== true ) {
			$settings_service->set( self::OPTION_ACTIVATED_ONCE, true );
			$settings_service->set( self::OPTION_ROUTER_ACTIVE, ! $press_service->has_device_identification() );
		}
	}

	public function save_mode() {
		if ( $_POST['availability'] == Mrf_Availability_Modes_Enum::ALL ) {
			$amp = ! isset( $_POST['amp'] ) || $_POST['amp'] == 1;
			$this->activate_all( $amp );
		} else {
			$settings_service = Marfeel_Press_App::make( 'settings_service' );
			$settings_service->set_option_data( self::OPTION_AVAILABILITY, $_POST['availability'] );
		}
	}

	public function track_mode_change( $current_availability, $new_availability ) {
		if ( isset( $_COOKIE['mrf-press-userid'] ) ) {
			$google_code_url = 'https://script.google.com/macros/s/AKfycbxH9ZRzR0FO9gugcIW8XgN7NCAas5CHPTVOTX6AEahZHRZYsww/exec';
			$request_body = array(
				'id' => $_COOKIE['mrf-press-userid'],
			);

			if ( $current_availability === Mrf_Availability_Modes_Enum::ALL && $new_availability !== Mrf_Availability_Modes_Enum::ALL ) {
				$request_body['deactivated'] = true;
			} elseif ( $current_availability !== Mrf_Availability_Modes_Enum::ALL && $new_availability === Mrf_Availability_Modes_Enum::ALL ) {
				$request_body['activated'] = true;
			}
			Marfeel_Press_App::make( 'http_client' )->request( 'POST', $google_code_url, array(
				'body' => wp_json_encode( $request_body ),
			) );
		}
	}
}
