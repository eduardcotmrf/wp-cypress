<?php


namespace Admin\Pages\Settings;

use Ioc\Marfeel_Press_App;

class Mrf_Activation_Checker {

	public function __construct() {
		$this->http_client = Marfeel_Press_App::make( 'http_client' );
		$this->definition_service = Marfeel_Press_App::make( 'definition_service' );
	}

	public function get_activation_uri( $tenant_home, $producer_host ) {

		$producer_host = $producer_host != null ? $producer_host : $this->definition_service->get( 'marfeel_press.producer_host' );
		$tenant_home   = $tenant_home != null ? $tenant_home : $this->definition_service->get( 'tenant_home' );
		$uri           = $producer_host . '/' . $tenant_home . '/index.html?marfeeldt=s&marfeelgarda=off';

		Marfeel_Press_App::make( 'log_provider' )->write_log( 'ActivationChecker: ping ' . $producer_host . ' for tenant: ' . $uri, 'd' );

		return $uri;
	}

	public function is_prod_ready( $tenant_home = null, $producer_host = null ) {

		$uri = $this->get_activation_uri( $tenant_home, $producer_host );
		$response    = $this->http_client->request( 'GET', $uri, array(
			'timeout' => 20,
		));

		$provider = Marfeel_Press_App::make( 'log_provider' );

		if ( is_wp_error( $response ) ) {
			$provider->write_log( 'ActivationChecker: wp error for: ' . $uri . ' | ' . $response->get_error_message() );
			return false;
		} elseif ( $response['response']['code'] == 200 ) {
			return true;
		}

		$provider->write_log( 'ActivationChecker: error for: ' . $uri . ' | error code: ' . $response['response']['code'] );

		return false;
	}

	public function check_existence( $uri ) {
		$response = $this->http_client->request( 'GET', $uri, array(
			'timeout' => 1,
		));

		return ! is_wp_error( $response ) && $response['response']['code'] != 404;
	}
}
