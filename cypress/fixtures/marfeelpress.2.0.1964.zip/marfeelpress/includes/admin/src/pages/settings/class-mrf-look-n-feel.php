<?php

namespace Admin\Pages\Settings;

use Ioc\Marfeel_Press_App;

class Mrf_Look_N_Feel extends Mrf_Settings {

	public function context_modifier( $context ) {
		$context = parent::context_modifier( $context );

		$context->page = 'brandingpress/siteIdentity';

		return $context;
	}

	public function get_setting_id() {
		return 'looknfeel';
	}
}
