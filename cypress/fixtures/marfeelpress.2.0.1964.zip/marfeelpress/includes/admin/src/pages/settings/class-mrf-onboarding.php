<?php

namespace Admin\Pages\Settings;

use Base\Entities\Settings\Mrf_Tenant_Type;
use Ioc\Marfeel_Press_App;

class Mrf_Onboarding extends Mrf_Settings {

	public function __construct() {
		parent::__construct();
		$this->utils = Marfeel_Press_App::make( 'page_utils' );
	}

	protected function get_tracking_id() {
		return 'getting_started';
	}

	public function get_setting_id() {
		return 'onboarding';
	}

	public function save( $context ) {
		$this->utils->save_mode();
	}

	public function context_modifier( $context ) {
		$context = parent::context_modifier( $context );
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		if ( $context->activated_once || $settings_service->get( 'marfeel_press.pending_to_activate' ) ) {
			$context->page = 'postonboarding';
		}

		return $context;
	}

	public function get_setting_url() {
		return get_admin_url() . 'admin.php?page=' . $this->id;
	}
}
