<?php

namespace Admin\Pages\Settings;

class Mrf_Advertising extends Mrf_Settings {

	public function get_setting_id() {
		return 'advertising';
	}

}
