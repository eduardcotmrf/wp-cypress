<?php

namespace Admin\Pages\Settings;

use Admin\Marfeel_Press_Admin_Translator;
use Base\Entities\Settings\Mrf_Availability_Modes_Enum;
use Base\Entities\Settings\Mrf_Tenant_Type;
use Ioc\Marfeel_Press_App;

class Mrf_Advanced extends Mrf_Settings {

	const OPTION_AVAILABILITY = 'mrf_availability';
	const OPTION_AMP = 'marfeel_press.amp.activate';
	const OPTION_RESOURCES_HOST = 'user_interface.resources_host';
	const OPTION_PRODUCER_HOST = 'marfeel_press.producer_host';
	const OPTION_TENANT_HOME = 'tenant_home';
	const OPTION_TENANT_URI = 'uri';
	const OPTION_POST_TYPE = 'post_type';
	const OPTION_API_TOKEN = 'marfeel_press.api_token';
	const OPTION_TENANT_TYPE = 'marfeel_press.tenant_type';
	const OPTION_MEDIA_GROUP = 'marfeel_press.media_group';
	const OPTION_AUTOUPDATE = 'marfeel_press.autoupdate';
	const OPTION_ERROR_REPORTING = 'marfeel_press.error_reporting';
	const OPTION_INSIGHT_TOKEN = 'marfeel_press.insight_token';
	const OPTION_AVOID_QUERY_PARAMS = 'marfeel_press.avoid_query_params';
	const OPTION_MARFEEL_SW_NAME = 'user_interface.features.pwa.sw_name_id';
	const OPTION_PLUGIN_STATUS = 'marfeel_press.plugin_status';
	const OPTION_DISABLE_MULTIPAGE = 'marfeel_press.disable_multipage';
	const OPTION_MRF_ROUTER = 'marfeel_press.mrf_router_active';
	const OPTION_LEROY = 'marfeel_press.leroy_active';
	const OPTION_CACHE = 'marfeel_press.cache_active';

	const DEFAULT_MODE = Mrf_Availability_Modes_Enum::OFF;

	public function is_default() {
		return true;
	}

	public function get_setting_id() {
		return 'advanced';
	}

	public function context_modifier( $context ) {
		if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['signup'] ) ) {
			$this->signup( $context );
		}

		$context->toast_display = isset( $context->toast_display ) ? $context->toast_display : 'none';
		$context->insight_token = $this->settings_service->get( self::OPTION_INSIGHT_TOKEN );

		if ( empty( $context->insight_token ) && ! Marfeel_Press_App::make( 'request_utils' )->is_dev() ) {
			$context->template              = 'mrf-signup-template.php';
			return $context;
		}

		$context->tenant_type           = esc_attr( $this->settings_service->get( self::OPTION_TENANT_TYPE ) );
		$context->is_longtail           = $context->tenant_type === Mrf_Tenant_Type::LONGTAIL;
		$context->is_dev                = Marfeel_Press_App::make( 'request_utils' )->is_dev() ? 1 : 0;
		$context->template              = 'mrf-advanced-template.php';
		$context->post_type             = $this->settings_service->get( self::OPTION_POST_TYPE, 'post' );
		$context->variant               = isset( $context->variant ) ? $context->variant : '';
		$context->message_txt           = isset( $context->message_txt ) ? $context->message_txt : '';
		$context->autoupdate            = $this->settings_service->get( self::OPTION_AUTOUPDATE );
		$context->error_reporting       = $this->settings_service->get( self::OPTION_ERROR_REPORTING );
		$context->selected_availability = $this->settings_service->get_option_data( self::OPTION_AVAILABILITY, self::DEFAULT_MODE );
		$context->mrf_router            = $this->settings_service->get( self::OPTION_MRF_ROUTER );
		$context->leroy                 = $this->settings_service->get( self::OPTION_LEROY );
		$context->cache                 = $this->settings_service->get( self::OPTION_CACHE );

		$context->post_types = get_post_types( array(
			'public' => true,
			'publicly_queryable' => true,
		) );

		$option_amp = $this->settings_service->get( self::OPTION_AMP );
		$context->amp = ( $option_amp || $option_amp === null ) ? "1" : "0";

		$context->options = array(
			array(
				'mode'        => Mrf_Availability_Modes_Enum::ALL,
				'description' => Marfeel_Press_Admin_Translator::trans( 'mrf.activation.all' ),
			),
			array(
				'mode'        => Mrf_Availability_Modes_Enum::LOGGED,
				'description' => Marfeel_Press_Admin_Translator::trans( 'mrf.activation.logged' ),
			),
			array(
				'mode'        => Mrf_Availability_Modes_Enum::OFF,
				'description' => Marfeel_Press_Admin_Translator::trans( 'mrf.activation.off' ),
			),
		);

		if ( $context->is_dev ) {
			$context->resources_host = esc_attr( $this->settings_service->get( self::OPTION_RESOURCES_HOST ) );
			$context->producer_host = esc_attr( $this->settings_service->get( self::OPTION_PRODUCER_HOST ) );
			$context->tenant_home = esc_attr( $this->settings_service->get( self::OPTION_TENANT_HOME ) );
			$context->tenant_uri = esc_attr( $this->settings_service->get( self::OPTION_TENANT_URI ) );
			$context->media_group = esc_attr( $this->settings_service->get( self::OPTION_MEDIA_GROUP ) );
			$context->api_token = esc_attr( $this->settings_service->get( self::OPTION_API_TOKEN ) );
			$context->log_provider = Marfeel_Press_App::make( 'text_file_log_provider' );
			$context->avoid_query_params = esc_attr( $this->settings_service->get( self::OPTION_AVOID_QUERY_PARAMS ) );
			$context->marfeel_sw_name_id = esc_attr( $this->settings_service->get( self::OPTION_MARFEEL_SW_NAME ) );
			$context->disable_multipage = esc_attr( $this->settings_service->get( self::OPTION_DISABLE_MULTIPAGE ) );

			$context->permalink_structure = get_option( 'permalink_structure' );
		}

		if ( ! isset( $context->content_saved ) && ! isset( $_POST['signup'] ) && $_SERVER['REQUEST_METHOD'] === 'POST' ) {
			$this->save( $context );
		}

		return $context;
	}

	public function has_been_submitted( $prop ) {
		return isset( $_POST[ $prop ] ) && $_POST[ $prop ] == 1;
	}

	public function save( $context ) {

		if ( $this->has_been_submitted( 'reset' ) && $_POST['is-dev'] == 1 ) {
			$this->settings_service->remove_all();
			echo '<h1>Factory settings reset</h1>';
			die;

		} elseif ( isset( $_POST['reset-version'] ) ) {
			$versions = $this->settings_service->get( 'marfeel_press.versions' );
			$versions['timestamp'] = 0;
			$this->settings_service->set( 'marfeel_press.versions', $versions );

		} elseif ( $this->has_been_submitted( 'ok' ) ) {
			$this->set_success_msg( $context );

			$values = array(
				self::OPTION_AUTOUPDATE      => isset( $_POST['autoupdate'] ),
				self::OPTION_ERROR_REPORTING => isset( $_POST['error-reporting'] ),
				self::OPTION_INSIGHT_TOKEN   => sanitize_text_field( $_POST['insight-token'] ),
				self::OPTION_AMP             => isset( $_POST['amp'] ),
				self::OPTION_POST_TYPE       => sanitize_text_field( $_POST['post-type'] ),
				self::OPTION_MRF_ROUTER      => isset( $_POST['mrf_router'] ),
				self::OPTION_LEROY           => true,
				self::OPTION_CACHE           => isset( $_POST['cache'] ),
			);

			if ( ! $context->is_longtail ) {
				$values[ self::OPTION_LEROY ]      = isset( $_POST['leroy'] );
			}

			if ( $_POST['is-dev'] == 1 ) {
				$permalink_structure = get_option( 'permalink_structure' );

				$values = array_merge( $values, array(
					self::OPTION_RESOURCES_HOST => sanitize_text_field( $_POST['resources-host'] ),
					self::OPTION_PRODUCER_HOST => sanitize_text_field( $_POST['producer-host'] ),
					self::OPTION_TENANT_HOME => sanitize_text_field( $_POST['tenant-home'] ),
					self::OPTION_TENANT_URI => sanitize_text_field( $_POST['tenant-uri'] ),
					self::OPTION_TENANT_TYPE => isset( $_POST['move-to-enterprise'] ) ? Mrf_Tenant_Type::ENTERPRISE : sanitize_text_field( $_POST['tenant-type'] ),
					self::OPTION_MEDIA_GROUP => sanitize_text_field( $_POST['media-group'] ),
					self::OPTION_API_TOKEN => sanitize_text_field( $_POST['api-token'] ),
					self::OPTION_AVOID_QUERY_PARAMS => ! empty( $permalink_structure ) && isset( $_POST['avoid-query'] ),
					self::OPTION_MARFEEL_SW_NAME => sanitize_text_field( $_POST['marfeel-sw-name-id'] ),
					self::OPTION_DISABLE_MULTIPAGE => isset( $_POST['disable-multipage'] ),
				) );
			}

			$this->settings_service->set( $values );
		} else {
			$this->set_error_msg( $context, 'Error!' );
		}

		if ( isset( $_POST['availability'] ) ) {
			$utils = Marfeel_Press_App::make( 'page_utils' );
			$current_availability = $this->settings_service->get_option_data( self::OPTION_AVAILABILITY, self::DEFAULT_MODE );
			$utils->track_mode_change( $current_availability, $_POST['availability'] );
			$utils->save_mode();
			$this->track_plugin_deactivated( $current_availability, $_POST['availability'] );
		}

		$context->content_saved = true;

		if ( ! Marfeel_Press_App::make( 'activation_checker' )->is_prod_ready() ) {
			$this->set_error_msg( $context, 'Your Marfeel mobile version is being generated. Please try in a few minutes!' );
			$context->selected_availability = $this->settings_service->set_option_data( self::OPTION_AVAILABILITY, self::DEFAULT_MODE );
			$context->content_saved         = false;
		}

		$this->context_modifier( $context );
	}

	private function signup( $context ) {
		$insight_signup = Marfeel_Press_App::make( 'insight_signup_service' );

		$body = Marfeel_Press_App::make( 'json_serializer' )->unserialize( $_POST, 'Base\Entities\Mrf_SignUp' );

		$insight_response = $insight_signup->signup( $body );
		if ( is_wp_error( $insight_response ) || Marfeel_Press_App::make( 'error_utils' )->is_error_response( $insight_response ) ) {
			if ( is_wp_error( $insight_response ) ) {
				$error = $insight_response->get_error_message( $insight_response->get_error_code() );
			} else {
				$error = $insight_response['body'];
			}

			$this->set_error_msg( $context, $error );
		}
	}

	private function track_plugin_deactivated( $current_availability, $new_availability ) {
		if ( $current_availability === Mrf_Availability_Modes_Enum::ALL && $new_availability === Mrf_Availability_Modes_Enum::OFF ) {
			Marfeel_Press_App::make( 'deactivator' )->track_deactivation( false );
		}
	}

	private function set_error_msg( $context, $text ) {
		$context->variant       = 'mrf-icon__alert';
		$context->message_txt   = $text;
		$context->toast_display = 'flex';
	}

	private function set_success_msg( $context, $message = 'Options saved!' ) {
		$context->variant       = 'mrf-icon__check-green';
		$context->message_txt   = $message;
		$context->toast_display = 'flex';
	}
}
