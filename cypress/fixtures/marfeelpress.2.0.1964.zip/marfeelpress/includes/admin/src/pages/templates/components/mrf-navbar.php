<?php
	use Admin\Pages\Settings\Mrf_Settings;
?>

<nav class="navbar navbar-expand sticky-top">
	<a class="navbar-brand navbar-dark" href="admin.php?page=onboarding">
		<?php require_once( MRFP__MARFEEL_PRESS_ADMIN_TEMPLATES_DIR . 'components/mrf-logo.php' ); ?>
	</a>

	<h1 class="navbar-title font-weight-bold"><?php echo $context->title; ?></h1>

</nav>
