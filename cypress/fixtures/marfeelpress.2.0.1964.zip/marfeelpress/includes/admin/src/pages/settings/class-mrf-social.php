<?php

namespace Admin\Pages\Settings;

use Ioc\Marfeel_Press_App;

class Mrf_Social extends Mrf_Settings {

	public function context_modifier( $context ) {
		$context = parent::context_modifier( $context );

		$context->page = 'social';

		return $context;
	}

	public function get_setting_id() {
		return 'socialNetworks';
	}
}
