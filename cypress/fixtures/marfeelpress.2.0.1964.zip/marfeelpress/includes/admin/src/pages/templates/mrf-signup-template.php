<div class="p-5">
	<h5 class="section-title">Signup</h5>
	<hr class="mb-5">

	<form method="post" action="">
		<div class="form-group row ">
			<label for="post-type" class="align-items-center col-4 col-form-label d-flex justify-content-end">
				Email
			</label>
			<div class="col-6">
				<input type="text" name="user_email" class="form-control" value="" />
			</div>
		</div>

		<div class="row">
			<div class="col-11 text-right">
				<button type="submit" class="btn btn-success" name="signup">Signup</button>
			</div>
		</div>
	</form>
</div>

<?php require_once( MRFP__MARFEEL_PRESS_ADMIN_TEMPLATES_DIR . 'components/mrf-notification-message.php' ); ?>
