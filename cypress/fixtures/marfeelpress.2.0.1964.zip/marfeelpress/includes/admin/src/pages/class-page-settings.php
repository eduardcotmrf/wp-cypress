<?php

namespace Admin\Pages;

use Admin\Marfeel_Press_Admin_Translator;
use Admin\Mode\Marfeel_Press_Admin;
use Admin\Pages\Settings\Mrf_Settings;
use Ioc\Marfeel_Press_App;

class Page_Settings extends Page {

	const PAGE_ID = 'mrf.page.settings';
	const OPTION_SECTIONS_STEP_STATUS = 'marfeel_press.sections_step_status';
	const OPTION_LOOKNFEEL_STEP_STATUS = 'marfeel_press.looknfeel_step_status';

	/** @var stdClass */
	protected $context;

	public function load_content( $context ) {
		$this->load_leroy_styles();
		require_once( MRFP__MARFEEL_PRESS_ADMIN_TEMPLATES_DIR . 'mrf-settings-template.php' );
	}

	protected function remove_tab_if_no_adtxt( $array_settings ) {
		$ads_txt = Marfeel_Press_App::make( 'settings_service' )->get( 'ads.ads_txt' );
		$has_ads_txt_plugin = $ads_txt->has_plugin;

		$arr_sett_length = count( $array_settings );

		for ( $i = 0; $i < $arr_sett_length; $i++ ) {
			if ( $this->should_remove_ads_txt_tab( $array_settings, $i, $has_ads_txt_plugin ) ) {
				unset( $array_settings[ $i ] );
				return $array_settings;
			}
		}

		return $array_settings;
	}

	private function should_remove_ads_txt_tab( $array_settings, $i, $has_ads_txt_plugin ) {
		$is_ads_txt_tab = $array_settings[ $i ]->id != null && $array_settings[ $i ]->id == 'adstxt';

		return $is_ads_txt_tab && $has_ads_txt_plugin ;
	}

	public function add_page( $context, $add_to_sidebar = true ) {
		Marfeel_Press_App::make( 'tracker' )->identify();
		$context->settings = Marfeel_Press_App::make( 'admin_settings' );
		$context->settings = $this->remove_tab_if_no_adtxt( $context->settings );

		$that = $this;

		add_submenu_page(
			$add_to_sidebar ? Marfeel_Press_Admin::MENU_ID : null,
			Mrf_Settings::PAGE_ID,
			Marfeel_Press_Admin_Translator::trans( self::PAGE_ID ),
			'manage_options',
			Mrf_Settings::PAGE_ID,
			function() use ( $context, $that ) {
				$context->page = isset( $_GET['action'] ) ? $_GET['action'] : 'advanced';

				foreach ( $context->settings as $setting ) {
					if ( $setting->id == $context->page ) {
						break;
					}
				}

				$setting->context_modifier( $context );

				$that->load_page( Marfeel_Press_Admin_Translator::trans( 'mrf.setting.' . $setting->id ), $context );
			}
		);
	}
}
