<?php

namespace Admin\Mode;

use Base\Entities\Mrf_Model;
use Base\Entities\Settings\Mrf_Tenant_Type;
use Ioc\Marfeel_Press_App;
use Admin\Pages\Settings\Mrf_Settings;

class Marfeel_Press_Admin {

	const MENU_ID = 'onboarding';

	/** @var string */
	protected $_admin_templates;

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'create_mrf_admin_menu' ) );
		add_action( 'admin_menu', array( $this, 'create_mrf_admin_submenu' ) );
		add_action( 'admin_bar_menu', array( $this, 'create_mrf_admin_bar_menu' ), 100 );

		add_action( 'add_meta_boxes', array( $this, 'add_non_marfeelizable_option' ) );
		add_action( 'save_post', array( $this, 'save_post' ), 10, 2 );

		$invalidator = Marfeel_Press_App::make( 'press_admin_invalidator' );
		add_action( 'save_post', array( $invalidator, 'invalidate_post' ), 1 );
		add_action( 'pre_post_update', array( $invalidator, 'save_post_data_pre_update' ), 10, 2 );
		add_action( 'post_updated', array( $invalidator, 'invalidate_section' ), 10, 3 );

		add_action( 'wp_ajax_marfeel', array( Marfeel_Press_App::make( 'admin_ajax' ), 'handle' ) );

		Marfeel_Press_App::make( 'versions_service' )->init();
		Marfeel_Press_App::make( 'log_provider' )->debug_if_dev( 'marfeelPressWatcher: Marfeel_Press_Admin created' );

		Marfeel_Press_App::make( 'deactivator' )->add_deactivation_popup();
	}

	public function add_non_marfeelizable_option( $post_type ) {
		if ( $post_type === Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ) ) {
			$this->non_marfeelizable_post();
		} elseif ( $post_type === 'page' ) {
			$this->non_marfeelizable_page();
		}
	}

	public function non_marfeelizable_post() {
		add_meta_box(
			'mrf_post_marfeelizable',
			'Marfeel',
			array( $this, 'marfeel_post_meta' ),
			Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ),
			'side'
		);
	}

	public function non_marfeelizable_page() {
		add_meta_box(
			'mrf_page_marfeelizable',
			'Marfeel',
			array( $this, 'marfeel_post_meta' ),
			'page',
			'side'
		);
	}

	public function marfeel_post_meta( $post ) {
		$meta = get_post_meta( $post->ID, 'mrf_marfeelizable', true );
		$no_marfeelize = is_numeric( $meta ) && $meta == 0;

		include __DIR__ . '/../templates/post/marfeel-meta.php';
	}

	public function save_post( $post_id, $post ) {
		if ( isset( $_POST['mrf_no_marfeelizable'] ) ) {
			update_post_meta( $post_id, 'mrf_marfeelizable', 0 );
		} elseif ( $post->post_type == Marfeel_Press_App::make( 'definition_service' )->get( 'post_type' ) || $post->post_type == 'page' ) {
			delete_post_meta( $post_id, 'mrf_marfeelizable' );
		}
	}

	public function get_admin_context() {
		$context = new Mrf_Model();
		$context->version = MRFP_LEROY_BUILD_NUMBER;
		$context->mrf_logo_src = MRFP__MARFEEL_PRESS_ADMIN_RESOURCES_DIR . 'images/marfeel_logo_rgb.svg';

		return $context;
	}

	public function create_mrf_admin_menu() {
		add_menu_page(
			null,
			'MarfeelPress',
			'manage_options',
			static::MENU_ID,
			null,
			MRFP__MARFEEL_PRESS_RESOURCES_URL . 'icons/svg/marfeel-leaf_grey.svg'
		);
	}

	public function create_mrf_admin_bar_menu( $admin_bar ) {
		$tenant_type = Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.tenant_type' );
		$menu_href = ( $tenant_type == Mrf_Tenant_Type::LONGTAIL || static::MENU_ID == 'onboarding' ) ? 'onboarding' : Mrf_Settings::PAGE_ID . '&action=' . static::MENU_ID;

		$icon_class = 'mrf-logo';
		$icon = '<img id = "white_icon" src = "' . MRFP__MARFEEL_PRESS_RESOURCES_URL . 'icons/svg/marfeel-leaf_grey.svg' . '" class = "' . $icon_class . '"></img>';
		$icon_blue = '<img id = "blue_icon" src = "' . MRFP__MARFEEL_PRESS_RESOURCES_URL . 'icons/svg/marfeel-leaf_blue.svg' . '" class = "' . $icon_class . '"></img>';

		$admin_bar->add_menu( array(
			'id'    => 'marfeel-menu',
			'title' => $icon . $icon_blue,
			'href'  => 'admin.php?page=' . $menu_href,
			'meta'  => array(),
		));
	}
}
