<?php
	use Admin\Marfeel_Press_Admin_Translator;
?>

<label for="mrf_no_marfeelizable">
	<input type="checkbox" id="mrf_no_marfeelizable" name="mrf_no_marfeelizable"<?php echo $no_marfeelize ? ' checked' : ''; ?> />
	<?php echo Marfeel_Press_Admin_Translator::trans( 'post.marfeelizable' ); ?>
</label>
