<?php

use Admin\Mode\Marfeel_Press_Admin_Lite;
use Admin\Mode\Marfeel_Press_Admin_Full;
use Admin\Pages\Settings\Mrf_Activation_Checker;
use Admin\Pages\Settings\Mrf_Ads;
use Admin\Pages\Settings\Mrf_Ads_Txt;
use Admin\Pages\Settings\Mrf_Analytics;
use Admin\Pages\Settings\Mrf_Comments;
use Admin\Pages\Settings\Mrf_Pwa;
use Admin\Pages\Settings\Mrf_Advanced;
use Admin\Pages\Settings\Mrf_Look_N_Feel;
use Admin\Pages\Settings\Mrf_Onboarding;
use Admin\Pages\Settings\Mrf_Sections;
use Admin\Pages\Settings\Mrf_Social;
use Admin\Pages\Settings\Mrf_Notifications;
use Admin\Pages\Settings\Mrf_Account;
use Admin\Pages\Settings\Mrf_Advertising;
use Admin\Pages\Page_Settings;
use Admin\Pages\Page_Settings_Lite;
use Admin\Pages\Page_Start;
use Admin\Pages\Page_Account;
use Admin\Pages\Page_Utils;
use Admin\Pages\Page_Notifications;
use Ads_Txt\Controllers\Marfeel_Press_Ads_Txt_Controller;
use Ads_Txt\Marfeel_Ads_Txt_Plugin_Support;
use Ads_Txt\Routers\Marfeel_Press_Ads_Txt_Router;
use Amp\Routers\Marfeel_Press_AMP_Router;
use API\availability\Mrf_Availability_Api;
use API\Definition\Mrf_Definition_API;
use API\Definition\Mrf_Ads_Txt_API;
use API\Definition\Mrf_Press_Settings_API;
use API\Menu\Mrf_Default_Menu_Service;
use API\Menu\Mrf_Menu_Api;
use API\Menu\Mrf_Menu_Categories_Api;
use API\Proxy\Mrf_Proxy_Api;
use API\Proxy\Mrf_Proxy_Utils;
use API\Twister\Mrf_Twister_API;
use API\Extract\Extractors\Api_Section_Extractor;
use API\Extract\Extractors\Api_Post_Extractor;
use API\Extract\Extractors\Api_Page_Extractor;
use API\SignUp\Mrf_Insight_Signup_API;
use API\SignUp\Services\Mrf_Insight_SignUp_Service;
use API\SignUp\Services\Mrf_Dev_Insight_SignUp_Service;
use API\SignUp\Services\Mrf_Insight_Token_Service;
use API\SignUp\Services\Mrf_Insight_Invalidator_Service;
use API\Export\Exporters\Mrf_Ai1wpm_Exporter_Factory;
use API\Export\Preparators\Mrf_Export_Tmp_Posts_Related_Preparator;
use API\Export\Preparators\Mrf_Export_Tmp_Tables_Preparator;
use API\Extract\Marfeel_Press_Ripper_API;
use API\Extract\Marfeel_Press_Extractor_API;
use API\Mrf_Upgrade_API;
use API\Marfeel_REST_API;
use Base\Entities\Mrf_Marfeel_Definition;
use Base\Marfeel_Press_Activator;
use Base\Marfeel_Press_Deactivator;
use Base\Marfeel_Press_Uninstaller;
use Base\Marfeel_Press_Updater;
use Base\Marfeel_Press_Device_Detection;
use Base\Marfeel_Press_Proxy;
use Base\Repositories\Posts_Repository;
use Base\Repositories\Posts_Meta_Repository;
use Base\Repositories\Terms_Repository;
use Base\Services\Definition\Marfeel_Press_Definition_Default_Builder;
use Base\Services\Definition\Marfeel_Press_Definition_Settings_Builder;
use Base\Services\Definition\Marfeel_Press_Definition_WP_Builder;
use Base\Services\Insight\Marfeel_Press_Insight_Service;
use Base\Services\Marfeel_Press_Custom_Headers_Service;
use Base\Services\Marfeel_Press_Head_Service;
use Base\Services\Marfeel_Press_Marfeel_Definition_Service;
use Base\Services\Marfeel_Press_Sections_Service;
use Base\Services\Marfeel_Press_Service;
use Base\Services\Marfeel_Press_Custom_Service;
use Base\Services\Marfeel_Press_Settings_Service;
use Base\Services\Marfeel_Press_Versions_Service;
use Base\Services\Marfeel_Press_Terms_Service;
use Base\Services\Marfeel_Press_Top_Media_Service;
use Base\Services\Marfeel_Press_WP_Service;
use Base\Services\Marfeel_Press_WP_Features_Service;
use Base\Utils\Http_Client;
use Base\Utils\Image_Utils;
use Base\Utils\Error_Utils;
use Base\Utils\Json_Serializer;
use Base\Utils\Mrf_Database_Wrapper;
use Base\Utils\Mrf_Filesystem_Wrapper;
use Base\Utils\Reflection_Utils;
use Base\Utils\Uri_Utils;
use Base\Utils\Request_Utils;
use Base\Descriptor\Marfeel_Item_Buffer;
use Base\Descriptor\Marfeel_Press_Article_Loader;
use Base\Descriptor\Filter\Ripper_Filter;
use Base\Descriptor\Parser\Json_Parser;
use Base\Descriptor\Reader\Post_Body_Reader;
use Base\Descriptor\Layout\Tags_Slider_Layout_Composer;
use Base\Descriptor\Layout\Slider_Layout_Composer;
use Base\Descriptor\Layout\Balcon_Layout_Composer;
use Base\Descriptor\Layout\Ads_Layout_Composer;
use Base\Descriptor\Layout\Article_Layout_Composer;
use Base\Descriptor\Layout\Photo2_Layout_Composer;
use Base\Descriptor\Layout\Decorator\Tags_Slider\Tags_Slider_Menu_Decorator;
use Base\Inventory\Inventory_Filler;
use Base\Inventory\Inventory_Finder;
use Base\Inventory\Inventory_Renderer;
use Base\Inventory\Loader\Inventory_Loader;
use Base\Inventory\Loader\Marfeel_Inventory_Loader;
use Base\Inventory\Loader\File_Inventory_Loader;
use Ads_Txt\Marfeel_Ads_Txt_Loader;
use Base\Trackers\Marfeel_Press_Tracker;
use Pwa\Routers\Marfeel_Press_SW_Router;
use Mrf\Routers\Marfeel_Press_MRF_Router;
use Admin\Marfeel_Press_Admin_Invalidator;
use Admin\Marfeel_Press_Admin_Ajax;

use Error_Handling\Marfeel_Press_Error_Handler;
use Error_Handling\Writers\Marfeel_Press_Monolog_File_Writer;
use Error_Handling\Writers\Marfeel_Press_Monolog_Kibana_Writer;
use Error_Handling\Providers\Marfeel_Press_Text_File_Log_Provider;
use Error_Handling\Providers\Marfeel_Press_Kibana_Log_Provider;
use Marfeel\Monolog\Logger;
use Ioc\Marfeel_Press_App;
use Base\Marfeel_Press_Activation_Requirements_Checker;
use API\SignUp\Mrf_Insight_Key;
use Base\Cron\Marfeel_Scheduler;
use Base\Cron\Marfeel_Activation_Cron_Job;
use Base\Services\Marfeel_Press_Content_Service;

Marfeel_Press_App::singleton( 'insight_service', function () {
	return new Marfeel_Press_Insight_Service();
} );

Marfeel_Press_App::singleton( 'proxy', function () {
	return new Marfeel_Press_Proxy();
} );

Marfeel_Press_App::singleton( 'requirements_checker', function () {
	return new Marfeel_Press_Activation_Requirements_Checker();
} );

Marfeel_Press_App::bind( 'wp_service', function () {
	return new Marfeel_Press_WP_Service();
});

Marfeel_Press_App::bind( 'wp_features_service', function () {
	return new Marfeel_Press_WP_Features_Service();
});

Marfeel_Press_App::singleton( 'posts_repository', function() {
	return new Posts_Repository();
} );

Marfeel_Press_App::singleton( 'posts_meta_repository', function() {
	return new Posts_Meta_Repository();
} );

Marfeel_Press_App::singleton( 'terms_repository', function() {
	return new Terms_Repository();
} );

Marfeel_Press_App::singleton( 'definition_builders', function () {
	return array(
		new Marfeel_Press_Definition_Default_Builder(),
		new Marfeel_Press_Definition_WP_Builder(),
		new Marfeel_Press_Definition_Settings_Builder(),
	);
} );

Marfeel_Press_App::singleton( 'image_utils', function () {
	return new Image_Utils();
} );

Marfeel_Press_App::singleton( 'error_utils', function () {
	return new Error_Utils();
} );

Marfeel_Press_App::singleton( 'press_service', function () {
	return new Marfeel_Press_Service();
} );

Marfeel_Press_App::singleton( 'content_service', function () {
	return new Marfeel_Press_Content_Service();
} );

Marfeel_Press_App::singleton( 'custom_service', function () {
	return new Marfeel_Press_Custom_Service();
} );

Marfeel_Press_App::singleton( 'head_service', function () {
	return new Marfeel_Press_Head_Service();
} );

Marfeel_Press_App::singleton( 'definition_service', function () {
	return new Marfeel_Press_Marfeel_Definition_Service();
} );

Marfeel_Press_App::singleton( 'definition_default_builder', function () {
	return new Marfeel_Press_Definition_Default_Builder();
} );

Marfeel_Press_App::singleton( 'definition_settings_builder', function () {
	return new Marfeel_Press_Definition_Settings_Builder();
} );

Marfeel_Press_App::singleton( 'section_service', function () {
	return new Marfeel_Press_Sections_Service();
} );

Marfeel_Press_App::singleton( 'top_media_service', function () {
	return new Marfeel_Press_Top_Media_Service();
} );

Marfeel_Press_App::singleton( 'settings_service', function () {
	return new Marfeel_Press_Settings_Service();
} );

Marfeel_Press_App::singleton( 'versions_service', function () {
	return new Marfeel_Press_Versions_Service();
} );

Marfeel_Press_App::singleton( 'terms_service', function () {
	return new Marfeel_Press_Terms_Service();
} );

Marfeel_Press_App::singleton( 'definition_entity', function () {
	return new Mrf_Marfeel_Definition();
} );

Marfeel_Press_App::singleton( 'mobile_detect', function () {
	return new Marfeel_Mobile_Detect();
} );

Marfeel_Press_App::singleton( 'device_detection', function () {
	return new Marfeel_Press_Device_Detection();
} );

Marfeel_Press_App::singleton( 'filesystem_wrapper', function () {
	return new Mrf_Filesystem_Wrapper();
} );

Marfeel_Press_App::singleton( 'reflection_utils', function () {
	return new Reflection_Utils();
} );

Marfeel_Press_App::singleton( 'json_serializer', function () {
	return new Json_Serializer();
} );

Marfeel_Press_App::singleton( 'http_client', function () {
	return new Http_Client();
} );

Marfeel_Press_App::singleton( 'uri_utils', function () {
	return new Uri_Utils();
} );

Marfeel_Press_App::singleton( 'request_utils', function () {
	return new Request_Utils();
} );

Marfeel_Press_App::bind( 'plugin_upgrader', function() {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-includes/pluggable.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

	return new Plugin_Upgrader();
} );

Marfeel_Press_App::singleton( 'marfeel_press_ads_txt_controller', function () {
	return new Marfeel_Press_Ads_Txt_Controller();
} );

Marfeel_Press_App::singleton( 'text_file_log_provider', function () {
	return new Marfeel_Press_Text_File_Log_Provider();
} );

Marfeel_Press_App::singleton( 'error_handler', function () {
	return new Marfeel_Press_Error_Handler();
} );

Marfeel_Press_App::singleton( 'log_file_writer', function () {
	return new Marfeel_Press_Monolog_File_Writer();
} );

Marfeel_Press_App::singleton( 'log_file_path', function () {
	return MRFP__MARFEEL_PRESS_DIR . '/mrf-errors';
} );

Marfeel_Press_App::singleton( 'log_kibana_writer', function () {
	return new Marfeel_Press_Monolog_Kibana_Writer();
} );

Marfeel_Press_App::singleton( 'log_level', function () {
	if ( isset( $_REQUEST['marfeelDev'] ) && $_REQUEST['marfeelDev'] == 1 ) {
		return Logger::DEBUG;
	}
	return Logger::WARNING;
} );

Marfeel_Press_App::singleton( 'logger', function () {
	return new Logger( 'mrfLogger' );
} );

Marfeel_Press_App::singleton( 'custom_headers_service', function () {
	return new Marfeel_Press_Custom_Headers_Service();
} );

Marfeel_Press_App::singleton( 'api_extractor_wp_term', function () {
	return new Api_Section_Extractor();
} );

Marfeel_Press_App::singleton( 'api_extractor_wp_post', function () {
	return new Api_Post_Extractor();
} );

Marfeel_Press_App::singleton( 'api_extractor_wp_post_page', function () {
	return new Api_Page_Extractor();
} );

Marfeel_Press_App::singleton( 'ripper_api', function () {
	return new Marfeel_Press_Ripper_API();
} );

Marfeel_Press_App::singleton( 'extractor_api', function () {
	return new Marfeel_Press_Extractor_API();
} );

Marfeel_Press_App::singleton( 'rest_api', function () {
	return new Marfeel_REST_API();
} );

Marfeel_Press_App::singleton( 'definition_api', function () {
	return new Mrf_Definition_API();
} );

Marfeel_Press_App::singleton( 'ads_txt_api', function () {
	return new Mrf_Ads_Txt_API();
} );

Marfeel_Press_App::singleton( 'twister_api', function () {
	return new Mrf_Twister_API();
} );

Marfeel_Press_App::singleton( 'upgrade_api', function () {
	return new Mrf_Upgrade_API();
} );

Marfeel_Press_App::singleton( 'signup_api', function () {
	return new Mrf_Insight_Signup_API();
} );

Marfeel_Press_App::singleton( 'key_api', function () {
	return new Mrf_Insight_Key();
} );

Marfeel_Press_App::singleton( 'insight_signup_service', function () {
	if ( strpos( $_SERVER['HTTP_HOST'], MRF_DEV_DOMAIN ) !== false ) {
		return new Mrf_Dev_Insight_SignUp_Service();
	}

	return new Mrf_Insight_SignUp_Service();
} );

Marfeel_Press_App::singleton( 'insight_token_service', function () {
	return new Mrf_Insight_Token_Service();
} );

Marfeel_Press_App::singleton( 'log_provider', function() {
	if ( Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.error_reporting' ) ) {
		return new Marfeel_Press_Kibana_Log_Provider();
	}

	return new Marfeel_Press_Text_File_Log_Provider();
} );

Marfeel_Press_App::bind( 'exporter_factory', 'ai1wpm_exporter_factory' );

Marfeel_Press_App::singleton( 'activator', function () {
	return new Marfeel_Press_Activator();
} );

Marfeel_Press_App::singleton( 'deactivator', function () {
	return new Marfeel_Press_Deactivator();
} );

Marfeel_Press_App::singleton( 'updater', function () {
	return new Marfeel_Press_Updater();
} );

Marfeel_Press_App::singleton( 'uninstaller', function () {
	return new Marfeel_Press_Uninstaller();
} );

Marfeel_Press_App::singleton( 'admin_settings', function () {
	return array(
		new Mrf_Analytics(),
		new Mrf_Sections(),
		new Mrf_Social(),
		new Mrf_Comments(),
		new Mrf_Pwa(),
		new Mrf_Advertising(),
		new Mrf_Look_N_Feel(),
		new Mrf_Ads_Txt(),
		new Mrf_Advanced(),
	);
} );

Marfeel_Press_App::singleton( 'onboarding_settings', function () {
	return array(
		new Mrf_Onboarding(),
		new Mrf_Analytics(),
		new Mrf_Comments(),
		new Mrf_Pwa(),
		new Mrf_Social(),
		new Mrf_Look_N_Feel(),
		new Mrf_Ads(),
		new Mrf_Advertising(),
		new Mrf_Ads_Txt(),
		new Mrf_Advanced(),
		new Mrf_Sections(),
	);
} );

Marfeel_Press_App::singleton( 'notifications_setting', function () {
	return new Mrf_Notifications();
} );

Marfeel_Press_App::singleton( 'activation_checker', function () {
	return new Mrf_Activation_Checker();
} );

Marfeel_Press_App::singleton( 'account_setting', function () {
	return new Mrf_Account();
} );

Marfeel_Press_App::singleton( 'onboarding_setting', function () {
	return new Mrf_Onboarding();
} );

Marfeel_Press_App::singleton( 'general_setting', function () {
	return new Mrf_Analytics();
} );

Marfeel_Press_App::singleton( 'page_settings', function () {
	return new Page_Settings();
} );

Marfeel_Press_App::singleton( 'page_settings_lite', function () {
	return new Page_Settings_Lite();
} );

Marfeel_Press_App::singleton( 'page_start', function () {
	return new Page_Start();
} );

Marfeel_Press_App::singleton( 'page_account', function () {
	return new Page_Account();
} );

Marfeel_Press_App::singleton( 'page_notifications', function () {
	return new Page_Notifications();
} );

Marfeel_Press_App::singleton( 'page_utils', function () {
	return new Page_Utils();
} );

Marfeel_Press_App::singleton( 'mrf_router', function () {
	return new Marfeel_Press_MRF_Router();
} );

Marfeel_Press_App::singleton( 'amp_router', function () {
	return new Marfeel_Press_AMP_Router();
} );

Marfeel_Press_App::singleton( 'sw_router', function () {
	return new Marfeel_Press_SW_Router();
} );

Marfeel_Press_App::singleton( 'ads_txt_router', function () {
	return new Marfeel_Press_Ads_Txt_Router();
} );

Marfeel_Press_App::bind( 'ai1wm_directory', 'Ai1wm_Directory' );

Marfeel_Press_App::singleton( 'descriptor_body_reader', function ( $container, $section ) {
	return new Post_Body_Reader( $section );
} );

Marfeel_Press_App::bind( 'descriptor_json_parser', function ( $container, $section ) {
	return new Json_Parser( $section );
} );

Marfeel_Press_App::bind( 'descriptor_layout_tagsSlider', function ( $container, $layout ) {
	return new Tags_Slider_Layout_Composer( $layout );
} );

Marfeel_Press_App::bind( 'descriptor_layout_slider', function ( $container, $layout ) {
	return new Slider_Layout_Composer( $layout );
} );

Marfeel_Press_App::bind( 'descriptor_layout_balcon', function ( $container, $layout ) {
	return new Balcon_Layout_Composer( $layout );
} );

Marfeel_Press_App::bind( 'descriptor_layout_layoutRoba', function ( $container, $layout ) {
	return new Ads_Layout_Composer( $layout );
} );

Marfeel_Press_App::bind( 'descriptor_layout_photo_grid_2', function ( $container, $layout ) {
	return new Photo2_Layout_Composer( $layout );
} );

Marfeel_Press_App::bind( 'descriptor_layout', function ( $container, $layout ) {
	return new Article_Layout_Composer( $layout );
} );

Marfeel_Press_App::singleton( 'descriptor_ripper_filter', function() {
	return new Ripper_Filter();
} );

Marfeel_Press_App::bind( 'tags_slider_decorator_menu', function ( $container, $attributes ) {
	return new Tags_Slider_Menu_Decorator( $attributes );
} );

Marfeel_Press_App::singleton( 'descriptor_article_loader', function () {
	return new Marfeel_Press_Article_Loader();
} );

Marfeel_Press_App::singleton( 'item_buffer', function () {
	return new Marfeel_Item_Buffer();
} );

Marfeel_Press_App::singleton( 'inventory_loader', function () {
	return new Inventory_Loader();
} );

Marfeel_Press_App::singleton( 'marfeel_inventory_loader', function ( $container, $type ) {
	return new Marfeel_Inventory_Loader( $type );
} );

Marfeel_Press_App::singleton( 'marfeel_ads_txt_loader', function () {
	return new Marfeel_Ads_Txt_Loader();
} );

Marfeel_Press_App::singleton( 'tenant_inventory_loader', function () {
	return new File_Inventory_Loader();
} );

Marfeel_Press_App::singleton( 'inventory_finder', function () {
	return new Inventory_Finder();
} );

Marfeel_Press_App::singleton( 'inventory_renderer', function () {
	return new Inventory_Renderer();
} );

Marfeel_Press_App::singleton( 'inventory_filler', function () {
	return new Inventory_Filler();
} );

Marfeel_Press_App::singleton( 'translator', function () {
	return '\Admin\Marfeel_Press_Admin_Translator';
} );

Marfeel_Press_App::singleton( 'ai1wm_mysql', function () {
	global $wpdb;

	if ( empty( $wpdb->use_mysqli ) ) {
		return new Ai1wm_Database_Mysql( $wpdb );
	}

	return new Ai1wm_Database_Mysqli( $wpdb );
} );

Marfeel_Press_App::bind( 'ai1wm_controller', function () {
	return new Ai1wm_Main_Controller();
} );

Marfeel_Press_App::bind( 'ai1wpm_exporter_factory', function () {
	return new Mrf_Ai1wpm_Exporter_Factory();
} );

Marfeel_Press_App::singleton( 'export_preparator_tmp_posts', function () {
	return new Mrf_Export_Tmp_Posts_Related_Preparator();
} );

Marfeel_Press_App::singleton( 'export_preparator_tmp_tables', function () {
	return new Mrf_Export_Tmp_Tables_Preparator();
} );

Marfeel_Press_App::bind( 'ai1wm_export_controller', function () {
	return new Ai1wm_Export_Controller();
} );

Marfeel_Press_App::bind( 'database_wrapper', function () {
	return new Mrf_Database_Wrapper();
} );

Marfeel_Press_App::bind( 'Analytics', 'Segment' );

Marfeel_Press_App::singleton( 'tracker', function () {
	return new Marfeel_Press_Tracker();
} );

Marfeel_Press_App::singleton( 'admin', function() {
	if ( Marfeel_Press_App::make( 'settings_service' )->is_lite() ) {
		new Marfeel_Press_Admin_Lite();
	} else {
		new Marfeel_Press_Admin_Full();
	}
} );

Marfeel_Press_App::singleton( 'admin_ajax', function() {
	return new Marfeel_Press_Admin_Ajax();
});

Marfeel_Press_App::singleton( 'press_admin_invalidator', function () {
	return new Marfeel_Press_Admin_Invalidator();
} );

Marfeel_Press_App::singleton( 'mrf_insight_invalidator_service', function () {
	return new Mrf_Insight_Invalidator_Service();
} );

Marfeel_Press_App::singleton( 'availability_api', function () {
	return new Mrf_Availability_Api();
} );

Marfeel_Press_App::singleton( 'menu_api', function () {
	return new Mrf_Menu_Api();
} );

Marfeel_Press_App::singleton( 'menu_categories_api', function () {
	return new Mrf_Menu_Categories_Api();
} );

Marfeel_Press_App::singleton( 'proxy_api', function () {
	return new Mrf_Proxy_Api();
} );

Marfeel_Press_App::singleton( 'proxy_utils', function () {
	return new Mrf_Proxy_Utils();
} );

Marfeel_Press_App::singleton( 'default_menu_service', function () {
	return new Mrf_Default_Menu_Service();
} );

Marfeel_Press_App::singleton( 'press_settings_api', function () {
	return new Mrf_Press_Settings_API();
} );

Marfeel_Press_App::singleton( 'scheduler', function () {
	return new Marfeel_Scheduler();
} );

Marfeel_Press_App::singleton( 'activation_cron_job', function () {
	return new Marfeel_Activation_Cron_Job();
} );

Marfeel_Press_App::singleton( 'ads_txt_plugin_support', function () {
	return new Marfeel_Ads_Txt_Plugin_Support();
} );
