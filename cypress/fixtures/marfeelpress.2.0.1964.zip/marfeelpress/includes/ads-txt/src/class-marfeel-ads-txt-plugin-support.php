<?php

namespace Ads_Txt;

use Ioc\Marfeel_Press_App;

class Marfeel_Ads_Txt_Plugin_Support {

	public function save_mrf_lines( $has_plugin ) {
		$mrf_lines = $this->get_mrf_lines();

		$this->save_ads_txt_settings( $mrf_lines, $has_plugin );

		if ( $has_plugin ) {
			$this->save_mrf_lines_in_plugin_file( $mrf_lines );
		}
	}

	private function save_mrf_lines_in_plugin_file( $mrf_lines ) {
		$post_id = get_option( 'adstxt_post' );

		if ( $post_id ) {
			$post = get_post( $post_id );
			$content = $post->post_content;

			if ( strpos( $content, '#MRF_LINES_START' ) == true ) {
				$content = $this->remove_lines( $content );
			}

			$this->add_lines( $post_id, $content, $mrf_lines );
		}
	}

	public function remove_mrf_lines() {
		$post_id = get_option( 'adstxt_post' );

		if ( $post_id ) {
			$post = get_post( $post_id );
			$content = $post->post_content;

			if ( strpos( $content, '#MRF_LINES_START' ) == true ) {
				$content = $this->remove_lines( $content );
				$this->update_ads_txt( $post_id, $content );
			}
		}
	}

	private function remove_lines( $content ) {
		$new_content = preg_replace( '/(#MRF_LINES_START[\S\s]*?#MRF_LINES_END)/', '', $content );

		return $new_content;

	}

	private function add_lines( $post_id, $content, $mrf_lines ) {
		$content .= "\n#MRF_LINES_START\n" . $mrf_lines . "\n#MRF_LINES_END";

		$this->update_ads_txt( $post_id, $content );
	}

	protected function get_mrf_lines() {
		return Marfeel_Press_App::make( 'marfeel_ads_txt_loader' )->load_mrf_lines();
	}

	protected function update_ads_txt( $post_id, $content ) {
		$postarr = array(
			'ID'           => $post_id,
			'post_title'   => 'Ads.txt',
			'post_content' => $content,
			'post_type'    => 'adstxt',
			'post_status'  => 'publish',
		);

		wp_insert_post( $postarr );
	}

	private function save_ads_txt_settings( $mrf_lines, $has_plugin ) {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );

		$ads_txt = $settings_service->get( 'ads.ads_txt' );
		$ads_txt->mrf_lines = $mrf_lines;
		$ads_txt->has_plugin = $has_plugin;

		$settings_service->set( 'ads.ads_txt', $ads_txt );
	}
}
