<?php

namespace Ads_Txt\Controllers;

use Base\Entities\Settings\Mrf_Tenant_Type;
use Ioc\Marfeel_Press_App;

class Marfeel_Press_Ads_Txt_Controller {
	const CACHE_TIME = 3600;
	const OPTION_TENANT_TYPE = 'marfeel_press.tenant_type';


	protected function set_headers() {
		header( 'Content-Type: text/plain' );
		header( 'HTTP/1.1 200 OK' );
	}

	protected function set_404_header() {
		header( 'HTTP/1.1 404 Not Found' );
	}

	public function render_ads_txt() {
		$ads_txt = $this->get_ads_txt();

		$tenant_type = esc_attr( Marfeel_Press_App::make( 'settings_service' )->get( self::OPTION_TENANT_TYPE ) );

		if ( ! empty( $ads_txt->content_merged ) && $this->had_ads_txt_before_marfeel( $ads_txt ) ) {
			$this->echo_content( $ads_txt->content_merged );
		} elseif ( $tenant_type === Mrf_Tenant_Type::LONGTAIL ) {
			$this->echo_content( $ads_txt->mrf_lines );
		} else {
			$this->set_404_header();
		}
	}

	private function echo_content( $content ) {
		$this->set_headers();

		echo $content;
	}

	protected function had_ads_txt_before_marfeel( $ads_txt ) {
		return $ads_txt->status > 0;
	}

	protected function get_ads_txt() {
		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$marfeel_ads_txt_loader = Marfeel_Press_App::make( 'marfeel_ads_txt_loader' );
		$ads_txt = $settings_service->get( 'ads.ads_txt' );
		$now = current_time( 'timestamp' );

		if ( $ads_txt->timestamp + self::CACHE_TIME < $now ) {
			if ( $ads_txt->status != 1 ) {
				$ads_txt = $marfeel_ads_txt_loader->load_merged( $ads_txt );
				$ads_txt->timestamp = $now;
				$settings_service->set( 'ads.ads_txt', $ads_txt );
			}
			Marfeel_Press_App::make( 'tracker' )->identify( false );
		}

		return $ads_txt;
	}

}
