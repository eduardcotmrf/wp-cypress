<?php

namespace Ads_Txt;

use Ioc\Marfeel_Press_App;

class Marfeel_Ads_Txt_Loader {

	public function load_merged( $ads_txt ) {
		$url = MRFP_INSIGHT_API . '/adstxt/' . Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' ) . '/?action=merge';

		$response = Marfeel_Press_App::make( 'http_client' )->request( 'POST', $url, array(
			'headers' => array(
				'Accept' => 'application/json; charset=utf-8',
			),
			'body' => $ads_txt->content,
		) );

		if ( $response['response']['code'] == 200 ) {
			$ads_txt->content_merged = str_replace( 'action=merge', '', $response['body'] );
		} else {
			$ads_txt->content_merged = 'error';
		}

		return $ads_txt;
	}

	public function load_mrf_lines() {
		$uri = MRFP_INSIGHT_API . '/adstxt/' . Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' ) . '/mrflines';

		$provider = Marfeel_Press_App::make( 'log_provider' );

		$response = Marfeel_Press_App::make( 'http_client' )->request( 'GET', $uri, array(
			'headers' => array(
				'Accept' => 'application/json; charset=utf-8',
			),
		) );

		if ( is_wp_error( $response ) ) {
			$provider->write_log( 'Marfeel_Ads_Txt_Loader: wp error for: ' . $uri . ' | ' . $response->get_error_message() );
			return null;
		} elseif ( $response['response']['code'] == 200 ) {
			return $response['body'];
		}

		$provider->write_log( 'Marfeel_Ads_Txt_Loader: error for: ' . $uri . ' | error code: ' . $response['response']['code'] );
		return null;
	}
}
