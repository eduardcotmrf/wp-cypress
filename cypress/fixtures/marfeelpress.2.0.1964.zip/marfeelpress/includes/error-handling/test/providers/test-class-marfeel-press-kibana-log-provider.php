<?php


use Error_Handling\Providers\Marfeel_Press_Kibana_Log_Provider;
use Ioc\Marfeel_Press_App;
use Ioc\WP_IOC_UnitTestCase;

class Marfeel_Press_Kibana_Log_Provider_Test extends WP_IOC_UnitTestCase {

	/** @var array */
	public static $added_documents = array();

	public function setUp() {
		parent::setUp();

		$this->singleton( 'http_client', 'supply_http_client' );
		$this->singleton( 'settings_service', 'supply_settings_service' );
		$this->singleton( 'device_detection', 'supply_device_detection' );
	}

	public function test_write_log() {
		$log_provider = new Marfeel_Press_Kibana_Log_Provider();

		$log_provider->write_log( 'Fake log message' );

		$this->assertNotFalse( isset( self::$added_documents['stack'] ) );

		unset( self::$added_documents['stack'] );
		unset( self::$added_documents['ts'] );

		$this->assertEquals( self::$added_documents, array(
			'buildNumber' => MRFP_MARFEEL_PRESS_BUILD_NUMBER != 'dev' ? MRFP_MARFEEL_PRESS_BUILD_NUMBER : 0,
			'customBuildNumber' => defined( 'MARFEEL_PRESS_CUSTOM_BUILD_NUMBER' ) ? MARFEEL_PRESS_CUSTOM_BUILD_NUMBER : '',
			'dh' => 'tenant.name',
			'dl' => 'example.org/mrf',
			'mdt' => 'S',
			'msg' => 'Fake log message',
			'severity' => 'error',
		) );
	}

	public function supply_http_client() {
		$mock = $this->getMock( 'Base\\Utils\\Http_Client', array( 'fire_and_forget' ) );
		$mock->method( 'fire_and_forget' )
			->willReturnCallback( function( $method, $url, $args ) {
				Marfeel_Press_Kibana_Log_Provider_Test::$added_documents = json_decode( $args['body'], true );

				unset( Marfeel_Press_Kibana_Log_Provider_Test::$added_documents['file'] );
				unset( Marfeel_Press_Kibana_Log_Provider_Test::$added_documents['line'] );
			} );

		return $mock;
	}

	public function supply_settings_service() {
		$mock = $this->getMock( 'Base\Services\Marfeel_Press_Settings_Service', array( 'get' ) );
		$mock->method( 'get' )
			->willReturn( 'tenant.name' );

		return $mock;
	}

	public function supply_device_detection() {
		$mock = $this->getMock( 'Base\Services\Marfeel_Press_Settings_Service', array( 'get_device_type' ) );
		$mock->method( 'get_device_type' )
			->willReturn( 'S' );

		return $mock;
	}
}
