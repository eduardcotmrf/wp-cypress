<?php

namespace Error_Handling\Writers;

use Ioc\Marfeel_Press_App;
use Error_Handling\Formatters\Kibana_Log_Formatter;
use Marfeel\Monolog\Processor\WebProcessor;
use Error_Handling\Handlers\Kibana_Log_Handler;
use Marfeel\Monolog\Logger;

class Marfeel_Press_Monolog_Kibana_Writer extends Marfeel_Press_Log_Writer {

	public function __construct() {
		parent::__construct();

		$handler = new Kibana_Log_Handler( Marfeel_Press_App::make( 'log_level' ) );
		$handler->setFormatter( new Kibana_Log_Formatter( 'press_errors-' . time(), 'event' ) );

		$this->log->pushHandler( $handler );

		$this->log->pushProcessor( new WebProcessor() );
	}
}
