<?php

namespace Error_Handling\Formatters;

use DateTime;
use Ioc\Marfeel_Press_App;
use Error_Handling\Marfeel_Press_Error_Handler;
use Marfeel\Monolog\Formatter\ElasticaFormatter;

class Kibana_Log_Formatter extends ElasticaFormatter {

	protected function get_stacktrace( $record ) {
		if ( strpos( $record['message'], '404' ) === false ) {
			return implode( "\n", array_filter( array_map( function( $stack ) {
				$trace = null;
				if ( isset( $stack['file'] ) && strpos( $stack['file'], 'Monolog' ) === false && strpos( $stack['file'], 'error-handling' ) === false ) {
					$trace = $stack['file'] . ':' . $stack['line'];
					if ( isset( $stack['class'] ) ) {
						$trace .= ' - ' . $stack['class'];
					}

					$trace .= '::' . $stack['function'];
				}
				return $trace;
			}, debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS ) ) ) ); // @codingStandardsIgnoreLine
		}

		return '';
	}

	protected function getDocument( $record ) {
		$date = new DateTime( $record['datetime'] );
		$host = Marfeel_Press_App::make( 'settings_service' )->get( 'tenant_home' );

		if ( empty( $host ) && isset( $_SERVER['HTTP_HOST'] ) ) {
			$host = $_SERVER['HTTP_HOST'];
		}

		return array(
			'buildNumber' => MRFP_MARFEEL_PRESS_BUILD_NUMBER != 'dev' ? MRFP_MARFEEL_PRESS_BUILD_NUMBER : 0,
			'customBuildNumber' => defined( 'MARFEEL_PRESS_CUSTOM_BUILD_NUMBER' ) ? MARFEEL_PRESS_CUSTOM_BUILD_NUMBER : '',
			'file' => Marfeel_Press_Error_Handler::$file,
			'line' => Marfeel_Press_Error_Handler::$line,
			'dh' => $host,
			'dl' => "{$record['extra']['server']}{$record['extra']['url']}",
			'mdt' => Marfeel_Press_App::make( 'device_detection' )->get_device_type(),
			'ts' => $date->getTimestamp() * 1000,
			'msg' => $record['message'],
			'stack' => $this->get_stacktrace( $record ),
			'severity' => strtolower( $record['level_name'] ),
		);
	}
}
