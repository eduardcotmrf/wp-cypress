<?php

namespace Error_Handling\Providers;

use Ioc\Marfeel_Press_App;

class Marfeel_Press_Kibana_Log_Provider extends Marfeel_Press_Log_Provider {

	/** @var Marfeel_Press_Monolog_Kibana_Writer */
	protected $log_writer;

	public function __construct() {
		$this->log_writer  = Marfeel_Press_App::make( 'log_kibana_writer' );
	}
}
