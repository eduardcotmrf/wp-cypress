<?php

namespace Error_Handling\Providers;
use Ioc\Marfeel_Press_App;

abstract class Marfeel_Press_Log_Provider {

	/** @var array */
	protected $modes = array(
		'd' => 'debug',
		'w' => 'warning',
		'e' => 'error',
		'c' => 'critical',
	);

	public function write_log( $text, $mode = 'e' ) {
		$this->log_writer->{$this->modes[ $mode ]}( $text );
	}

	public function debug_if_dev( $text ) {
		if ( Marfeel_Press_App::make( 'request_utils' )->is_dev() ) {
			$this->log_writer->{$this->modes['d']}( $text );
		}
	}
}
