<?php


namespace Error_Handling\Handlers;

use Marfeel\Monolog\Handler\ElasticSearchHandler;
use Ioc\Marfeel_Press_App;

class Kibana_Log_Handler extends ElasticSearchHandler {

	public function __construct( $level = Logger::DEBUG, $bubble = true ) {
		$this->setLevel( $level );
		$this->bubble = $bubble;
	}

	protected function bulkSend( array $records ) {
		$client = Marfeel_Press_App::make( 'http_client' );

		foreach ( $records as $doc ) {
			$client->fire_and_forget( 'POST', 'https://cosmos.marfeel.com:443/press_errors-' . time() . '/event', array(
				'headers' => array(
					'Content-Type' => 'application/json; charset=utf-8',
				),
				'body' => wp_json_encode( $doc ),
			) );
		}
	}
}
