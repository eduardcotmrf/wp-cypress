<?php

namespace API;

use Admin\Pages\Settings\Mrf_Advanced;
use Ioc\Marfeel_Press_App;

class Mrf_Upgrade_Api extends Mrf_API {

	public function __construct() {
		$this->resource_name    = 'upgrade';
		$this->allowed_methods  = array( Marfeel_REST_API::METHOD_READABLE );
	}

	protected function upgrade( $plugin_name ) {
		Marfeel_Press_App::make( 'plugin_upgrader' )->upgrade( $plugin_name );
		activate_plugin( $plugin_name );
	}

	protected function upgrade_custom() {
		$this->upgrade( 'marfeelpress-custom/marfeelpress-custom.php' );
	}

	protected function upgrade_main() {
		$this->upgrade( MRFP_MARFEEL_PRESS_PLUGIN_NAME . '/' . MRFP_MARFEEL_PRESS_PLUGIN_NAME . '.php' );
	}

	public function get() {
		if ( Marfeel_Press_App::make( 'settings_service' )->get( Mrf_Advanced::OPTION_AUTOUPDATE ) ) {
			if ( ! isset( $_GET['plugin'] ) ) {
				$_GET['plugin'] = null;
			}

			switch ( $_GET['plugin'] ) {
				case 'main':
					$this->upgrade_main();
					break;
				case 'custom':
					$this->upgrade_custom();
					break;
				default:
					$this->upgrade_main();
					$this->upgrade_custom();
					break;
			}
		} else {
			echo 'Autoupdates are deactivated';
		}
	}
}
