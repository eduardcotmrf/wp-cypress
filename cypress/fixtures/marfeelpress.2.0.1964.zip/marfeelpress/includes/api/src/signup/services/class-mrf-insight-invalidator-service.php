<?php

namespace API\SignUp\Services;

use Ioc\Marfeel_Press_App;


class Mrf_Insight_Invalidator_Service {

	const MAX_TIMEOUT_INSIGHT = 1;

	const INVALIDATE_HOME_3 = '/index.html?invalidate=3';

	/** @var string */
	public $action_param;

	/** @var string */
	public $insight_api_token;

	public function __construct() {
		$this->action_param = 'action=invalidate';
		$this->insight_api_token = Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.insight_token' );
	}

	public function invalidate_post( $post ) {
		$api_uri_param = 'uri=' . get_permalink( $post );
		$url = MRFP_INSIGHT_API . '/diy/articles?' . $this->action_param . '&' . $api_uri_param;
		Marfeel_Press_App::make( 'log_provider' )->write_log( 'Post invalidated at: ' . $url, 'w' );

		return Marfeel_Press_App::make( 'http_client' )->request( 'GET', $url, array(
			'headers' => array(
				'mrf-secret-key' => $this->insight_api_token,
			),
		) );
	}

	public function invalidate_section_array( $section_array ) {
		$response = array();

		$this->invalidate_section_link( Marfeel_Press_App::make( 'uri_utils' )->get_home_url() );

		foreach ( $section_array as $section ) {
			$this->invalidate_section( $section );
		}

		return true;
	}

	public function invalidate_all() {
		$tenant_home = Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' );
		$producer_host = Marfeel_Press_App::make( 'settings_service' )->get( 'marfeel_press.producer_host' );

		$url = $producer_host . '/' . $tenant_home . self::INVALIDATE_HOME_3;

		Marfeel_Press_App::make( 'log_provider' )->write_log( 'Tenant invalidated at: ' . $url, 'w' );
		return Marfeel_Press_App::make( 'http_client' )->request( 'GET', $url, array(
			'timeout' => 1,
			'headers' => array(
				'mrf-secret-key' => $this->insight_api_token,
			),
		) );
	}

	private function invalidate_section( $section ) {
		$this->invalidate_section_link( get_term_link( $section ) );
	}

	private function invalidate_section_link( $url ) {
		$api_uri_param = 'uri=' . $url;
		$url = MRFP_INSIGHT_API . '/diy/sections?' . $this->action_param . '&' . $api_uri_param;
		Marfeel_Press_App::make( 'log_provider' )->write_log( 'Section invalidated at: ' . $url, 'w' );

		return Marfeel_Press_App::make( 'http_client' )->request( 'GET', $url, array(
			'timeout' => 1,
			'headers' => array(
				'mrf-secret-key' => $this->insight_api_token,
			),
		)  );
	}
}

