<?php

namespace API\SignUp;

use Ioc\Marfeel_Press_App;
use API\Mrf_API;
use API\Marfeel_REST_API;
use WP_REST_Request;
use WP_REST_Response;

class Mrf_Insight_Signup_API extends Mrf_API {

	public function __construct() {
		$this->resource_name = 'register';
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_CREATABLE,
		);
	}

	public function register() {
		$api_params = $this->get_methods();
		$api_params[0]['timeout'] = 45;

		register_rest_route( $this->get_namespace(), '/signups/index/' . $this->resource_name, $api_params );
	}

	public function post( WP_REST_Request $request ) {
		$insight_signup = Marfeel_Press_App::make( 'insight_signup_service' );
		$error_utils = Marfeel_Press_App::make( 'error_utils' );
		$body = null;

		if ( $request->get_body() ) {
			$body = Marfeel_Press_App::make( 'json_serializer' )->unserialize( $request->get_body(), 'Base\Entities\Mrf_SignUp' );
		}

		$insight_response = $insight_signup->signup( $body );
		if ( is_wp_error( $insight_response ) || $error_utils->is_error_response( $insight_response ) ) {
			return $this->error_handler( $insight_response );
		}

		return new WP_REST_Response( '', 200 );
	}

	private function error_handler( $response ) {
		$code = 500;
		if ( is_wp_error( $response ) ) {
			$error = $response;
		} else {
			$error = $response['body'];
			$code = $response['response']['code'];
		}

		return new WP_REST_Response( $error, $code );
	}
}
