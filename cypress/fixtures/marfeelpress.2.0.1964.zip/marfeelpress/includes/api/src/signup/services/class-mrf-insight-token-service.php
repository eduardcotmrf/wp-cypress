<?php

namespace API\SignUp\Services;

use Ioc\Marfeel_Press_App;
use Base\Entities\Settings\Mrf_Tenant_Type;

class Mrf_Insight_Token_Service {
	const OPTION_INSIGHT_TOKEN = 'marfeel_press.insight_token';
	const OPTION_TENANT_TYPE = 'marfeel_press.tenant_type';
	const OPTION_MEDIA_GROUP = 'marfeel_press.media_group';
	const OPTION_MRF_ROUTER = 'marfeel_press.mrf_router_active';
	const OPTION_LEROY = 'marfeel_press.leroy_active';
	const LONGTAIL = 'LONGTAIL';

	/** @var Mrf_Settings_Service */
	private $settings_service;

	public function __construct() {
		$this->settings_service = Marfeel_Press_App::make( 'settings_service' );
	}

	public function save_response_data( $response ) {
		$is_longtail = $response->tenant_type == Mrf_Tenant_Type::LONGTAIL;

		$this->settings_service->set( self::OPTION_INSIGHT_TOKEN, $response->secret_key );
		$this->settings_service->set( self::OPTION_MEDIA_GROUP, $response->media_group );

		if ( ! $is_longtail ) {
			$this->settings_service->set( self::OPTION_TENANT_TYPE, $response->tenant_type );
		}

		$this->settings_service->set( self::OPTION_MRF_ROUTER, $is_longtail );
		$this->settings_service->set( self::OPTION_LEROY, $is_longtail );
	}

	public function user_has_token() {
		return ! ! $this->settings_service->get( self::OPTION_INSIGHT_TOKEN );
	}
}
