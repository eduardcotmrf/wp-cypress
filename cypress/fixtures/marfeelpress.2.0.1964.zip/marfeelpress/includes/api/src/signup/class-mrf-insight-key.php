<?php

namespace API\SignUp;

use API\Mrf_API;
use API\Marfeel_REST_API;
use Ioc\Marfeel_Press_App;
use WP_REST_Response;

class Mrf_Insight_Key extends Mrf_API {

	public function __construct() {
		$this->resource_name = 'mrf-key';
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_CREATABLE,
		);
	}

	public function post() {
		if ( isset( $_POST['secretKey'] ) ) {
			$response = Marfeel_Press_App::make( 'json_serializer' )->unserialize( $_POST, 'Base\Entities\Mrf_SignUp_Response' );
			Marfeel_Press_App::make( 'insight_token_service' )->save_response_data( $response );

			return new WP_REST_Response( '', 200 );
		}

		return new WP_REST_Response( '', 400 );
	}
}
