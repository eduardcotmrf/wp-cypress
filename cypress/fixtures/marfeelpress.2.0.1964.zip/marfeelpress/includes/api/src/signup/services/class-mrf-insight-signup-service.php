<?php
/**
 * Copyright (c) 2018 Marfeel Solutions (https://www.marfeel.com)
 * All Rights Reserved.*
 * NOTICE: All information contained herein is, and remains
 * the property of Marfeel Solutions S.L and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Marfeel Solutions S.L and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Marfeel Solutions SL.
 */
namespace API\SignUp\Services;

use WP_Error;
use Ioc\Marfeel_Press_App;
use Base\Entities\Mrf_Signup;

class Mrf_Insight_SignUp_Service {
	const OPTION_API_TOKEN = 'marfeel_press.api_token';
	const MARFEEL_EMAIL_DOMAIN = '@marfeel.com';

	/** @var stdClass */
	private $token_service;

	public function __construct() {
		$this->token_service = Marfeel_Press_App::make( 'insight_token_service' );
	}

	public function signup( $body = null ) {
		$response = '';
		$marfeel_email = null;
		$user_data = wp_get_current_user();

		if ( ! $this->token_service->user_has_token() ) {
			if ( $body instanceof Mrf_Signup && $body->user_email ) {
				$marfeel_email = $user_data->user_email;
				$user_data->user_email = $body->user_email;
			}

			$response = $this->register( $user_data, $marfeel_email );
		}

		return $response;
	}

	private function register( $user_data, $marfeel_email ) {
		$error_utils = Marfeel_Press_App::make( 'error_utils' );
		$response = null;

		if ( ! $this->is_marfeel_email( $user_data->user_email ) ) {
			$insight_response = $this->create_insight_user( $user_data, $marfeel_email );

			if ( is_wp_error( $insight_response ) || $error_utils->is_error_response( $insight_response ) ) {
				$response = $insight_response;
			} else {
				$response = Marfeel_Press_App::make( 'json_serializer' )->unserialize( $insight_response['body'], 'Base\Entities\Mrf_SignUp_Response' );
				$this->token_service->save_response_data( $response );
			}
		} else {
			$response = $this->marfeel_user_response();
		}

		return $response;
	}

	private function create_insight_user( $user_data, $marfeel_email ) {
		$client = Marfeel_Press_App::make( 'http_client' );
		$signup_request = $this->build_signup_request( $user_data, $marfeel_email );
		$signup_request = Marfeel_Press_App::make( 'json_serializer' )->serialize( $signup_request );

		$response = $client->request(
			$client::METHOD_POST,
			MRFP_INSIGHT_API . '/onboarding',
			array(
				'headers' => array(
					'content-type' => 'application/json',
				),
				'timeout' => 45,
				'blocking' => true,
				'body' => wp_json_encode( $signup_request ),
			)
		);

		$response_message = is_wp_error( $response ) ? $response->get_error_message() : wp_json_encode( $response['response'] );
		Marfeel_Press_App::make( 'log_provider' )->write_log( 'Registering user: ' . wp_json_encode( $signup_request ) . "\nResponse: " . $response_message, 'w' );

		return $response;
	}

	private function build_signup_request( $user_data, $marfeel_email ) {
		$token = Marfeel_Press_App::make( 'settings_service' )->get( self::OPTION_API_TOKEN );
		$tenant_uri = Marfeel_Press_App::make( 'definition_service' )->get()->tenant_home;
		$signup_request = new Mrf_SignUp();

		$signup_request->user_email = $user_data->user_email;
		$signup_request->first_name = $user_data->first_name;
		$signup_request->last_name = $user_data->last_name;
		$signup_request->tenant_uri = $tenant_uri;
		$signup_request->token = $token;

		if ( $marfeel_email ) {
			$signup_request->marfeel_email = $marfeel_email;
		}

		return $signup_request;
	}

	private function is_marfeel_email( $email ) {
		return substr( $email,  -strlen( self::MARFEEL_EMAIL_DOMAIN ) ) === self::MARFEEL_EMAIL_DOMAIN;
	}

	private function marfeel_user_response() {
		return new WP_Error(
			'invalid_fields',
			'marfeel_user',
			array(
				'status' => 400,
			)
		);
	}

	private function is_error_response( $response ) {
		return is_array( $response ) && $response['response']['code'] >= 400;
	}

}
