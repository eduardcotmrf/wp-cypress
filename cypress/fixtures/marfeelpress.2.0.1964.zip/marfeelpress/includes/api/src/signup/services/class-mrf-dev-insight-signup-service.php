<?php
/**
 * Copyright (c) 2018 Marfeel Solutions (https://www.marfeel.com)
 * All Rights Reserved.*
 * NOTICE: All information contained herein is, and remains
 * the property of Marfeel Solutions S.L and its suppliers,
 * if any. The intellectual and technical concepts contained
 * herein are proprietary to Marfeel Solutions S.L and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Marfeel Solutions SL.
 */
namespace API\SignUp\Services;

use WP_Error;
use Ioc\Marfeel_Press_App;
use Base\Entities\Mrf_Signup;

class Mrf_Dev_Insight_SignUp_Service {
	const OPTION_API_TOKEN = 'marfeel_press.api_token';
	const MARFEEL_EMAIL_DOMAIN = '@marfeel.com';

	/** @var stdClass */
	private $token_service;

	public function __construct() {
		$this->token_service = Marfeel_Press_App::make( 'insight_token_service' );
	}

	public function signup( $body = null ) {
		$response = '';
		$marfeel_email = null;
		$user_data = wp_get_current_user();

		if ( $body instanceof Mrf_Signup && $body->user_email ) {
			$marfeel_email = $user_data->user_email;
			$user_data->user_email = $body->user_email;
		}

		$response = $this->register( $user_data, $marfeel_email );

		return $response;
	}

	private function register( $user_data, $marfeel_email ) {
		$error_utils = Marfeel_Press_App::make( 'error_utils' );
		$response = null;

		$insight_response = $this->create_insight_user( $user_data, $marfeel_email );

		if ( is_wp_error( $insight_response ) || $error_utils->is_error_response( $insight_response ) ) {
			$response = $insight_response;
		} else {
			$response = Marfeel_Press_App::make( 'json_serializer' )->unserialize( $insight_response['body'], 'Base\Entities\Mrf_SignUp_Response' );
			$this->token_service->save_response_data( $response );
		}

		return $response;
	}

	private function create_insight_user( $user_data, $marfeel_email ) {
		$def_service = Marfeel_Press_App::make( 'definition_service' );

		$response = array(
			'response' => array(
				'code' => 200,
			),
			'body' => wp_json_encode(
				array(
					'tenant_type' => $def_service->get( Mrf_Insight_Token_Service::OPTION_TENANT_TYPE ),
					'media_group' => $def_service->get( Mrf_Insight_Token_Service::OPTION_MEDIA_GROUP ),
					'secret_key' => $def_service->get( Mrf_Insight_Token_Service::OPTION_INSIGHT_TOKEN ),
				)
			),
		);

		return $response;
	}

	private function is_error_response( $response ) {
		return is_array( $response ) && $response['response']['code'] >= 400;
	}

}
