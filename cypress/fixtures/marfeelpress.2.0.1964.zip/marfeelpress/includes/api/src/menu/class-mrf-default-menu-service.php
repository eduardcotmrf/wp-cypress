<?php

namespace API\Menu;

use Base\Entities\Insight\Mrf_Feed_Definitions;
use Base\Entities\Insight\Mrf_Menu;
use Base\Entities\Insight\Mrf_Section_Definitions;

class Mrf_Default_Menu_Service {

	/** @var array[] */
	private static $blacklist = array( 'marfeel', 'footer', 'social' );


	public function get_default_menu() {
		$mrf_menu = new Mrf_Menu();
		$menu     = $this->get_primary_menu();

		if ( ! empty( $menu ) ) {
			$menu_items = wp_get_nav_menu_items( $menu->term_id );

			foreach ( $menu_items as $key => $menu_item ) {
				$menu_item->level = $this->find_menu_item_level( $menu_item, $menu_items );

				if ( ! $this->is_duplicated_url( $menu_item->url, $mrf_menu->section_definitions ) ) {
					array_push( $mrf_menu->section_definitions, $this->create_section_definition( $menu_item, $mrf_menu->section_definitions ) );
				}
			}
		}

		return $mrf_menu;
	}

	private function find_menu_item_level( $menu_item, $menu_items ) {
		if ( $menu_item->menu_item_parent == 0 ) {
			return 0;
		}

		return 1 + $this->find_menu_item_level( $this->get_menu_item_by_id( $menu_item->menu_item_parent, $menu_items ), $menu_items );
	}

	private function get_menu_item_by_id( $menu_item_id, $menu_items ) {
		foreach ( $menu_items as $menu_item ) {
			if ( $menu_item->db_id == $menu_item_id ) {
				return $menu_item;
			}
		}
	}

	private function get_primary_menu() {
		$location  = $this->get_primary_location( get_nav_menu_locations() );
		$menu_item = wp_get_nav_menu_object( $location );

		return $menu_item != false ? $menu_item : null;
	}

	private function get_primary_location( $locations ) {
		$i = 0;

		$locations_keys = array_keys( $locations );

		$number_locations = sizeof( $locations_keys );
		while ( $i < $number_locations ) {
			if ( $this->is_blacklisted( $locations_keys[ $i ] ) && $this->has_items( $locations[ $locations_keys[ $i ] ] ) ) {
				return $locations[ $locations_keys[ $i ] ];
			}

			$i ++;
		}

		return null;
	}

	private function has_items( $menu ) {
		return $menu != null && sizeof( wp_get_nav_menu_items( $menu ) ) > 0;
	}

	private function is_blacklisted( $location ) {
		$j             = 0;
		$num_blacklist = sizeof( self::$blacklist );
		$primary       = true;
		while ( $j < $num_blacklist && $primary ) {
			$primary = strpos( $location, self::$blacklist[ $j ] ) === false ? true : false;
			$j ++;
		}

		return $primary;
	}

	private function create_section_definition( $menu_item, $section_definitions ) {

		$section_definition        = new Mrf_Section_Definitions();

		$latest_duplicated_section = $this->get_latest_section_with_duplicated_name( $menu_item, $section_definitions );

		if ( $latest_duplicated_section ) {
			$section_definition->name  = $this->create_name( $menu_item->title ) . '-' . $this->get_duplicated_section_index( $latest_duplicated_section );
		} else {
			$section_definition->name  = $this->create_name( $menu_item->title );
		}

		$section_definition->title = $menu_item->title;

		$feed_definition      = new Mrf_Feed_Definitions();
		$feed_definition->uri = $this->get_uri( $menu_item->url );

		$section_definition->feed_definitions = array( $feed_definition );

		$section_definition->type = $this->get_type( $menu_item->object, $menu_item->url );

		if ( $menu_item->level > 0 ) {
			$section_definition->level = $menu_item->level;
		}
		return $section_definition;
	}

	public function create_name( $title ) {
		return preg_replace( '/[^a-z]/', '', strtolower( $title ) );
	}

	public function get_type( $object, $url ) {
		switch ( strtoupper( $object ) ) {
			case 'PAGE':
			case 'POST':
				return 'STATIC';
			case 'TAG':
			case 'CATEGORY':
				return 'DEFAULT';
			case 'CUSTOM':
			default:
				return $this->is_empty_link( $url ) ? 'GROUP' : 'EXTERNAL';
		}
	}

	public function get_uri( $url ) {
		return $this->is_empty_link( $url ) ? null : $url;
	}

	private function is_empty_link( $url ) {
		return $url == '#';
	}

	private function is_duplicated_url( $url, $section_definitions ) {
		foreach ( $section_definitions as $section_definition ) {
			if ( $section_definition->feed_definitions[0]->uri == $url ) {
				return true;
			}
		}

		return false;
	}

	private function get_latest_section_with_duplicated_name( $menu_item, $section_definitions ) {
		$latest_duplicated = false;

		foreach ( $section_definitions as $section_definition ) {
			if ( $this->create_name( $section_definition->title ) == $this->create_name( $menu_item->title ) ) {
				$latest_duplicated = $section_definition;
			}
		}

		return $latest_duplicated;
	}

	private function get_duplicated_section_index( $section_definition ) {
		$exploded  = explode( '-', $section_definition->name );
		$last_part = $exploded[ count( $exploded ) - 1 ];

		return is_numeric( $last_part ) ? $last_part + 1 : 1;
	}

}
