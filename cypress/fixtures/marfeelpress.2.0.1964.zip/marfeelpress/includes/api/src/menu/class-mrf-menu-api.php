<?php

namespace API\Menu;

use API\Marfeel_REST_API;
use API\Mrf_API;
use Ioc\Marfeel_Press_App;
use WP_REST_Response;

class Mrf_Menu_Api extends Mrf_API {

	public function __construct() {
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_READABLE,
		);
	}

	public function register() {
		register_rest_route( $this->get_namespace(), '/menus/default', $this->get_methods() );
	}

	public function get() {
		$menu   = Marfeel_Press_App::make( 'default_menu_service' )->get_default_menu();
		$result = Marfeel_Press_App::make( 'json_serializer' )->serialize( $menu );

		return new WP_REST_Response( $result, 200 );
	}
}
