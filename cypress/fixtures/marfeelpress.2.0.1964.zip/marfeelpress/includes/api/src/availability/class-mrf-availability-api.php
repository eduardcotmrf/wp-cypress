<?php

namespace API\availability;

use API\Marfeel_REST_API;
use API\Mrf_API;
use Ioc\Marfeel_Press_App;
use WP_REST_Response;

class Mrf_Availability_Api extends Mrf_API {

	public function __construct() {
		$this->resource_name = 'plugin/availability';

		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_READABLE,
		);

		$this->unsecure_endpoint();
	}

	public function get() {
		$availability = new Mrf_Availability();
		$availability->availability = Marfeel_Press_App::make( 'settings_service' )->get_availability();

		$result = Marfeel_Press_App::make( 'json_serializer' )->serialize( $availability );

		return new WP_REST_Response( $result, 200 );
	}
}
