<?php

namespace API\availability;

class Mrf_Availability {
	/**
	 * @var string
	 * @json availability
	 */
	public $availability;
}
