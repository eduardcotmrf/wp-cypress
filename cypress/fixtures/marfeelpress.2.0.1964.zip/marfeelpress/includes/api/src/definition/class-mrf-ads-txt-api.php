<?php

namespace API\Definition;

use API\Definition\Mrf_Base_API;
use Ioc\Marfeel_Press_App;
use API\Marfeel_REST_API;
use WP_REST_Request;

class Mrf_Ads_Txt_API extends Mrf_Base_API {

	public function __construct() {
		$this->resource_name = 'ads/ads_txt';
		$this->target_class = 'Base\Entities\Advertisement\Mrf_Ads_Txt';
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_READABLE,
			Marfeel_REST_API::METHOD_CREATABLE,
		);
	}

	public function get() {
		$this->update_status();
		return parent::get();
	}

	public function validate( $body ) {
		return null;
	}

	private function update_status() {
		$mrf_lines = Marfeel_Press_App::make( 'marfeel_ads_txt_loader' )->load_mrf_lines();

		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$ads_txt = $settings_service->get( 'ads.ads_txt' );
		$response = $this->get_insight_status();

		if ( ! is_wp_error( $response ) && $response['response']['code'] === 200 ) {
			$result = json_decode( $response['body'] );
			if ( $result->status === 1 ) {
				$ads_txt->content = implode( PHP_EOL, $result->content );
			}
			$ads_txt->status = $result->status;
			$ads_txt->mrf_lines = $mrf_lines;
			$settings_service->set( 'ads.ads_txt', $ads_txt );
		}
	}

	protected function get_insight_status() {
		$client = Marfeel_Press_App::make( 'http_client' );
		$url = MRFP_INSIGHT_API . '/adstxt/' . Marfeel_Press_App::make( 'definition_service' )->get( 'tenant_home' ) . '/?action=validate';

		return $client->request(
			$client::METHOD_GET,
			$url,
			array(
				'headers' => array(
					'Accept' => 'application/json',
				),
			)
		);
	}

}
