<?php

namespace API\Definition;

use Ioc\Marfeel_Press_App;
use API\Marfeel_REST_API;
use WP_REST_Request;
use WP_REST_Response;

class Mrf_Press_Settings_API extends Mrf_Base_API {

	public function __construct() {
		$this->resource_name = 'marfeel_press';
		$this->target_class = 'Base\Entities\Settings\Mrf_Press_Setting';
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_READABLE,
		);
	}

	public function register() {
		register_rest_route( $this->get_namespace(), Mrf_Base_API::BASE . '/settings', $this->get_methods() );
		register_rest_route( $this->get_namespace(), Mrf_Base_API::BASE . '/settings/pendingToActivate', array(
			'methods' => Marfeel_REST_API::METHOD_CREATABLE,
			'callback' => array( $this, 'updatePendingToActivate' ),
		));
	}

	public function updatePendingToActivate( WP_REST_Request $request ) {
		$pending_to_activate = $request->get_param( 'pending_to_activate' );
		$pending_to_activate = $pending_to_activate === 'false' || $pending_to_activate === '0' ? false : true;

		$settings_service = Marfeel_Press_App::make( 'settings_service' );
		$settings_service->set( 'marfeel_press.pending_to_activate', $pending_to_activate );

		return new WP_REST_Response( $settings_service->get( 'marfeel_press.pending_to_activate' ), 200 );
	}

}
