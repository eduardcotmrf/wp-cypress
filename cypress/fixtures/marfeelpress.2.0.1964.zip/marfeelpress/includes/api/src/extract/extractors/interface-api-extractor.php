<?php

namespace API\Extract\Extractors;

interface Api_Extractor {

	public function extract();
}
