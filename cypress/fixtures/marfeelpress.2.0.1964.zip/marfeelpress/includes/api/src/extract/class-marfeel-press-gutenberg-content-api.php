<?php

namespace API\Extract;

use API\Mrf_API;
use WP_REST_Response;
use Ioc\Marfeel_Press_App;
use API\Marfeel_REST_API;
use Base\Marfeel_Press_Plugin_Conflict_Manager;


class Marfeel_Press_Gutenberg_Content_API extends Mrf_API {

	public function __construct() {
		$this->allowed_methods = array(
			Marfeel_REST_API::METHOD_READABLE,
			Marfeel_REST_API::METHOD_CREATABLE,
		);
	}

	protected function get_extractor() {}

	protected function process_request() {
		preg_match( '/[?&]url=([^&]+)/', $_SERVER['REQUEST_URI'], $matches );

		Marfeel_Press_App::make( 'wp_service' )->load_url( wp_parse_url( $matches[1], PHP_URL_PATH ) );

		Marfeel_Press_Plugin_Conflict_Manager::disable_extraction_plugins();

		$extractor = $this->get_extractor();

		$extraction = Marfeel_Press_App::make( 'json_serializer' )->serialize( $extractor->extract() );

		return new WP_REST_Response( $extraction, 200 );
	}

	public function post() {
		return $this->process_request();
	}

	public function get() {
		return $this->process_request();
	}
}
