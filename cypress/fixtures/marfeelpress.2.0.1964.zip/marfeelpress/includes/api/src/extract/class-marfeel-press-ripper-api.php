<?php

namespace API\Extract;

use API\Mrf_API;
use WP_REST_Response;
use Ioc\Marfeel_Press_App;
use API\Marfeel_REST_API;


class Marfeel_Press_Ripper_API extends Marfeel_Press_Gutenberg_Content_API {

	public function __construct() {
		parent::__construct();
		$this->resource_name = 'ripper';
	}

	protected function get_extractor() {
		$object = get_queried_object();

		if ( $object === null ) {
			global $wp_query;
			$wp_query->is_home = true;
			$class = 'WP_Term';
		} else {
			$class = get_class( $object );
		}

		$extractor = strtolower( $class );

		if ( $extractor == 'wp_post' && Marfeel_Press_App::offsetExists( 'api_extractor_' . $extractor . '_' . $object->post_type ) ) {
			$extractor .= '_' . $object->post_type;
		}

		return Marfeel_Press_App::make( 'api_extractor_' . $extractor );
	}

}
