<?php

namespace API\Extract\Extractors;

use stdClass;
use Base\Descriptor\Marfeel_Press_Layouts_Descriptor_Manager;
use Ioc\Marfeel_Press_App;

class Api_Section_Extractor extends Api_Items_Extractor {

	protected function get_item_hints() {
		$context = new stdClass();
		$context->param = new stdClass();
		$context->param->marfeel_context = '';

		$object = get_queried_object();
		if ( $object === null ) {
			$section = Marfeel_Press_App::make( 'section_service' )->get_home_section();
		} else {
			$section = Marfeel_Press_App::make( 'section_service' )->get_default_section( get_queried_object() );
		}

		$descriptor_reader = Marfeel_Press_App::make( 'descriptor_body_reader', $section );
		$ripper_filter = Marfeel_Press_App::make( 'descriptor_ripper_filter' );
		$manager = new Marfeel_Press_Layouts_Descriptor_Manager( $context, 'mrf', $descriptor_reader, $ripper_filter );
		$items = $manager->get_items();

		foreach ( $items as $item ) {
			$item->detail_item = null;
		}

		return $items;
	}
}
