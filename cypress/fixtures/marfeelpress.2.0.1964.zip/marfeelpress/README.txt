=== MarfeelPress ===
Contributors: alicemrf
Requires at least: 4.7
Tested up to: 5.0
Requires PHP: 5.3
Stable tag: 2.0.1964
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin provides an easy activation of full marfeel product suite.
== Description ==

MarfeelPress is loaded with all the features publishers and bloggers need for a top mobile site that will rival the biggest brands out there.

In a matter of minutes, get cutting-edge design, a sophisticated ad configuration with dynamic ad placement, instantaneous page speed, AMP pages, and customize it all with our easy-to-use editor.


= Engagement: =
Give your readers an app-like reading experience with features such as swipe, relevant push notifications, and recirculation strategies to increase page views.

= Speed: =
Optimizes and lazy loads media assets almost instantly with flawless quality. Ensures desktop assets won't load in the background, resulting in optimal speed.

= Customization: =
Keep complete control of the look and feel of your mobile website. Set your colors, upload your logo, and add your favorite analytics and commenting systems.

= Traffic: =
Profit from traffic channels such as Google AMP and Apple News, as well as an increase in speed that results in an improvement in SEO.

= Ad revenue =
Profit from sophisticated algorithms, including real-time bidding and server-to-server header bidding. Access global deals with industry-leading SSPs and ad networks, such as Google AdExchange.


= Discover more about the MarfeelPress plugin: =
[MarfeelPress](https://www.marfeel.com/wordpress/)
[Learn more about us](https://www.marfeel.com/)
[Documentation](https://atenea.marfeel.com/mp)


== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Done!


== Screenshots ==

1. Getting started MarfeelPress
2. PWA MarfeelPress
3. Analytics MarfeelPress
4. Customize MarfeelPress
5. Reporting MarfeelPress
